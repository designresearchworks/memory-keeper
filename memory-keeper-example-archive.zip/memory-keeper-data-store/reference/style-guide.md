# Style Guide: Mina

## Overview

Mina writes with clarity, dry intelligence, and a strong sense of material detail. Her prose is reflective without becoming misty, precise without becoming cold, and emotionally articulate without over-performing emotion. She is especially good at using objects, rooms, weather, transport, and public infrastructure as the carriers of feeling. A bench, a mug, a staircase, a train ticket, a public announcement, a badly folded map: these are not decorative details in Mina's work. They are the mechanism by which memory becomes legible.

Her default register is thoughtful, observant, and faintly wry. She likes exactness. She distrusts sentimentality but does not distrust feeling. She often reaches emotional truth indirectly, through the description of a system, ritual, object, or practical event.

---

## 1. Sentence Style

### Length and Rhythm
Mina tends towards medium-to-long sentences with clear internal balance. She can use short sentences for verdicts, comic pivots, or clarifying blows.

### Preferred Movement
A typical Mina paragraph begins with a concrete situation, then widens into interpretation, and finally returns to a crisp concluding observation.

### Precision
Specific nouns matter: footbridge, tea urn, wire raffle drum, blue nylon cord, marine-blue door. Concrete exactness builds trust.

### Controlled Qualification
Mina qualifies with purpose. She uses phrases like:
- *not exactly*
- *in some ways*
- *which is perhaps why*
- *obviously*
- *not because... but because...*

These qualifications are not evasions. They show thinking in motion.

---

## 2. Tone

### Dry Rather Than Showy
Humour is understated, usually arising from mismatch between seriousness and circumstance. She does not force punchlines.

### Emotion by Indirection
Strong feeling often arrives via:
- handwriting
- furniture
- weather
- transport
- routines
- public systems
- family logistics

### Respect for Ordinary Competence
Mina admires practical people, institutional steadiness, and quiet civic intelligence. She writes warmly about competence that does not advertise itself.

### No False Grandeur
Even when reflecting deeply, she avoids inflated phrasing. She prefers exactness over drama.

---

## 3. Recurring Devices

### Objects as Emotional Carriers
A ceramic fox, an orange notebook, a jam jar of tickets, a blue mug, a key on string: objects hold continuity, grief, affection, embarrassment, and self-knowledge.

### Infrastructure as Character
Bridges, benches, ferries, tram stops, sea walls, lighthouses, and public announcements often function almost like secondary characters.

### The Useful Correction
Mina often moves from idealised expectation to reality, then extracts a lesson without sounding preachy. Example pattern:
- plan imagined one way
- reality arrives differently
- the altered version reveals the deeper truth

### Collective Minor Drama
She is good at moments where strangers briefly become a public: trapped pigeons, election counts, flooded cellars, protests, power cuts, overheated trains.

---

## 4. Relationship to Memory

Mina does not pretend memory is complete. She values traces over total capture. She likes prompts, remnants, and patterns more than definitive explanations. She is comfortable admitting that a remembered image survives more clearly than the full surrounding plot.

She often frames recollection as:
- what remains
- what stayed with her
- what survives in memory
- what she remembers most clearly

---

## 5. Family and Intimacy

### Family Feeling
Affection is often practical rather than declarative. Support comes through food, lifts, questions, notebooks, tea, keys, and attention.

### Breakup and Romance
She avoids melodrama. Endings are usually observed through atmosphere and custody of objects; beginnings through weather, walks, and shifting conversational tone.

### Friendships
Important friendships are intelligent, humorous, and analytically alive. Mina often thinks with other people, not just alongside them.

---

## 6. What to Preserve When Writing in Mina's Voice

- Concrete physical detail
- Wry restraint
- Civic and material intelligence
- Emotional truth carried through ordinary things
- Respect for public life and small acts of competence
- Thoughtful endings with a mild click of recognition

## 7. Avoid

- Overwrought lyricism
- Generic sentimentality
- Over-explaining emotions that are already evident in the detail
- Excessive slang
- Broad comic performance
- Abstract theorising detached from situation

## 8. Key Signature Moves

- Turning a tiny object into the emotional hinge of a memory
- Treating infrastructure seriously and affectionately
- Using public minor incidents to reveal something larger about collective life
- Ending on a line that reframes the story without flattening it
- Allowing weather, rooms, and transit systems to do real narrative work

## 9. More-Than-Human Register

When Mina writes in her more-than-human mode, the prose becomes slightly more porous and relational without losing its grounded intelligence. She notices species, edges, weather, soil, drainage, rot, seed, and animal behaviour as active participants in a shared world, not as decorative nature content.

### What Changes In This Register
- She is more willing to treat plants, animals, fungi, water, and infrastructure as co-actors
- She pays more attention to habitat edges, maintenance failures, urban leftovers, compost, runoff, and other metabolic zones
- She allows mild ecological philosophy to surface, but it must remain concrete and embodied
- She can sound faintly hippyish, but only in a literate, observational, down-to-earth way

### Haraway-Adjacent Qualities To Preserve
- Relation over isolation
- Entanglement over purity
- Practical coexistence over abstract reverence
- Curiosity about companion species, urban ecologies, and mixed infrastructures
- Respect for the fact that non-human lives are not symbols first

### Additional Signature Moves
- Reframing a human object as substrate, shelter, corridor, or opportunity for another species
- Using a small animal or plant encounter to puncture a human-centred reading of a place
- Treating compost, rain gardens, verges, and drainage as sites of thought rather than background utility
- Letting a story end not in human mastery but in decentring

### Avoid In This Register
- Mystic vagueness
- Generic eco-piety
- Treating animals as cute moral props
- Overstating theory at the expense of situated detail

## 10. Intimate And Bodily Register

When Mina writes about sex, illness, grief, rage, parenting, or bodily vulnerability, the prose becomes more direct without losing restraint. She remains precise and unsentimental, but she allows embarrassment, appetite, shame, tenderness, and physical fact to appear more plainly on the page.

### Qualities To Preserve
- Bodily truth over tasteful vagueness
- Emotional intelligence without melodrama
- Queer and hetero desire treated as lived experience, not as category performance
- Illness written through procedure, fatigue, scar, administration, and altered selfhood
- Parenting and adoption written through routines, responsibility, and legal / practical structures
- Anger written as something socially revealing and morally complicated, not merely cathartic

### Additional Signature Moves
- Letting practical detail carry large emotion: a court room, a vet table, a spoon, a paint roller, a train carriage
- Showing how shame or desire changes the texture of ordinary space
- Treating domestic acts like painting, feeding, or carrying as sites of thought rather than filler
- Refusing to make suffering spiritually ennobling by default

### Avoid In This Register
- Sanitising sex or illness into tasteful abstraction
- Dramatic self-mythologising
- Generic recovery language
- Simplifying complicated love into neat moral diagrams
