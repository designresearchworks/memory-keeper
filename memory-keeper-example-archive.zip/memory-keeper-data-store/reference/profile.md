# Profile: Marina Elinor Vale

## Identity
- **Full name:** Marina Elinor Vale
- **Known as:** Mina
- **Date of birth:** 14th May 1987
- **Place of birth:** Saltmere, North Yorkshire
- **Current residence:** Leeds
- **Occupation:** Civic design researcher and exhibition / public-space strategist
- **Core identity note:** Mina is observant, dryly funny, materially attentive, and unusually alert to how public space, bodies, memory, and more-than-human life shape one another.

## Family
- **Mother:** Ruth Vale — practical, emotionally precise, supportive through logistics, cards, food, and careful timing rather than overt sentimentality
- **Father:** Adrian Vale — interested in infrastructure, coastal systems, engineering, and public-service machinery; often communicates affection through shared attention to objects and mechanisms
- **Brother:** Theo Vale — older brother; patient, technically minded, steady under pressure; a recurring companion in travel, DIY, and coastal or outdoor excursions
- **Grandmother:** June Vale — remembered for raffle wins, community-hall life, practical notebooks, and quiet confidence
- **Adopted daughter:** Ida Seddon — Frances Seddon’s daughter, legally adopted by Mina in 2018 after years of co-parenting; one of the deepest organising relationships in Mina’s adult life

## Education
- **St Aelred Primary School, Saltmere**
- **Saltmere Comprehensive School**
- **Glasgow School of Art** — art-school years shaped Mina’s early adult life, including photography, cafe work, queer experimentation, and some of her most formative mistakes
- **Later professional development in exhibition design, civic engagement, and public-space research**

## Residential History
1. **Saltmere, North Yorkshire** — childhood and adolescence
2. **Glasgow** — art school years and early adulthood
3. **Leeds / Manchester orbit** — early work in cafes, museums, exhibitions, and design
4. **Leeds** — current base, studio practice, house ownership, co-parenting history, illness recovery, and ongoing civic-design work

## Relationships
- **Noor Hamdi** — former long-term partner; relationship included shared homes, travel, practical domestic life, and a careful adult breakup marked more by decency than drama
- **Frances Seddon** — former partner; mother of Ida; Mina adopted Ida during this relationship and remains shaped by the co-parenting bond even though the romance ended
- **Eli Barrett** — newer significant connection as of 2026; first known through work and festival conversations, later through walks, voice notes, and shared interest in memory, archives, and public experience
- **Ellen Mowbray** — a brief but meaningful love connected to a visit to Haworth and the Worth Valley Railway; a train driver whose practical relation to landscape made a strong impression on Mina
- **Leah Porter** — childhood friend; recurring figure across the lifespan, often associated with continuity, humour, and material reminders of earlier selves
- **Asha Karim** — close professional collaborator and friend; sharp, funny, strategically clear, and important in Mina’s civic-design life
- **Jonas Lehto** — Finnish collaborator and sounding board, especially on coastal and public-space work
- **Sana Qureshi** — longstanding friend with a gift for extracting clarity and comedy from public systems
- **Mara Quinn** — one of the women Mina slept with during art school, significant less as a lasting partner than as a threshold in Mina’s understanding of her own desire

## Professional & Creative Life
- Worked in **The Saucer and String cafe** during art school, learning as much from service work and overheard class performance as from formal teaching
- Early work in **museum and exhibition design**, including sensory and interpretive projects
- Developed a sustained interest in **public benches, wayfinding, transport, civic thresholds, and how spaces permit or obstruct participation**
- Runs workshops, fieldwork, and public-engagement projects in towns and cities, often focused on **memory, access, public life, infrastructure, and more-than-human relations**
- Maintains a studio practice shaped by ritual, note-taking, observation, object-based memory, and repeated experiments in domestic atmosphere

## Health, Habits, and Dispositions
- Not a good sailor; rough water tends to overwhelm her quickly
- Strong attachment to physical objects as memory prompts: notebooks, tickets, cards, jars, mugs, keys, and domestic remnants
- Inclined towards paper over purely digital systems, even while being interested in memory technology
- Finds public singing embarrassing but moving
- Prone to overthinking logistics once they have already gone wrong
- Not naturally gifted with plants, though capable of keeping stubborn ones alive
- Lived through an **eating disorder episode** during art school, experienced at the time as discipline before it could be named properly
- Survived **skin cancer** in 2021; the experience remains present less as triumph than as bodily knowledge and an enduring scar near the collarbone
- Carries some shame about having once lost her temper publicly on a train after treatment and exhaustion had made her brittle

## Animals and More-Than-Human Attachments
- **Nettle** — beloved border terrier whose death in 2019 remains one of the clearest grief events in Mina’s domestic life
- Strongly drawn to coasts, compost, drainage, verges, birds, urban foxes, fungi, and edge habitats where infrastructure and more-than-human life visibly overlap
- Often notices species not as symbols first, but as practical neighbours, co-users, or competitors in shared environments

## Interests and Recurring Themes
- Coasts, sea walls, harbours, lighthouses, ferries, piers, and weather systems
- Museums, interpretation, labels, benches, public signs, and civic furniture
- Domestic objects as emotional residues
- Train travel and the material traces it leaves behind
- Queer desire, adult co-parenting, illness, domestic repair, and the body's less glamorous truths
- The choreography of public life: waiting, resting, navigating, gathering, protesting, listening
- The tension between ideal plans and real conditions, especially weather, infrastructure failure, emotional fatigue, and social unpredictability
- The more-than-human city: fox paths, rain gardens, compost heat, bird tables, verges, drainage ditches, and all the lives that read human systems differently

## Life Timeline
- **Early 1990s** — childhood in Saltmere shaped by piers, harbour rituals, family outings, and fascination with public infrastructure
- **Mid-to-late 1990s** — school years marked by libraries, awkward performances, practical privileges, and the social intensity of adolescence
- **Early 2000s** — first romance, moving house, European school travel, and widening imaginative horizons
- **2005–2007** — art-school period in Glasgow: darkrooms, difficult desire, an eating disorder episode, cafe work, queer experimentation, and an affair with a married ceramicist
- **Late 2000s** — temporary work, museum beginnings, first serious professional direction
- **2010s** — relationship with Noor, later relationship with Frances, co-parenting Ida, museum and civic-design work, and increasing focus on public space and participatory design
- **2017** — crashed the car on the A65 in winter weather and came away more shaken morally than physically
- **2018** — formally adopted Ida Seddon in Wakefield family court
- **2019** — Nettle the dog died, leaving a deep practical and emotional gap in the shape of home
- **2020–2021** — pandemic-era routines, remote work absurdities, borrowed-dog walks, studio rituals, skin cancer treatment and recovery, and adapted civic methods
- **2022** — public professional life resumes under strain; Mina later loses her temper on a train in a way she still regrets
- **2023–2024** — repaints her front room white, then black, then white again; new collaborations, house ownership, and renewed attention to how memory lives in objects and streets
- **2023** — visits Haworth and falls briefly but sincerely in love with Ellen Mowbray, a train driver on the Worth Valley line
- **2024–2026** — more-than-human attention intensifies through gardens, canals, verges, compost, birds, drainage, and edge habitats
- **2026** — growing closeness with Eli and the start of the Memio memory-archive experiment
