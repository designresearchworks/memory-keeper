# Story: The Exhibition That Smelled of Apples

## Metadata
Told: 2026-03-24T11:00:00.000Z
File: stories/the-exhibition-that-smelled-of-apples.md
Period: 2009
People: Mina Vale, Julian March
Places: Leeds City Museum
Themes: museum work, design, sensory experience, professional growth, experiments
Connections: The Call Centre Voice
Summary: On an early museum project, a curator insisted that an exhibition about orchards should literally smell of apples. The resulting compromise was technically imperfect but formative for Mina, who began to understand exhibition design as choreography rather than arrangement.

## Story

My first museum job involved helping install a small exhibition about regional orchards and fruit-growing. This would already have been more niche than my eighteen-year-old self had predicted for adult life. The further complication was that the curator, Julian March, believed absolutely that the exhibition should smell of apples.

He was not being whimsical. Julian had a serious argument about sensory memory and visitor immersion. He talked about atmosphere as though it were a civic duty. The practical challenge, however, was that museums tend to prefer not spraying unstable substances around cases full of historical material. After several meetings we arrived at a compromise involving concealed scent diffusers operating on a very restrained schedule.

The result was imperfect. If you entered at exactly the wrong moment the space smelt not of orchards but of a synthetic candle attempting sincerity. Yet the ambition of it stayed with me. Julian was right about one thing: exhibitions are not neutral containers for information. They cue bodies. They pace attention. They persuade people to feel that a sequence of objects belongs together.

I remember standing in the gallery before opening, lights still low, and realising that arrangement is only a small part of the work. The real challenge is orchestrating movement, expectation, and tempo. You are composing an encounter. The apples were perhaps a little too eager. But eagerness in the service of form is often where a profession starts.
