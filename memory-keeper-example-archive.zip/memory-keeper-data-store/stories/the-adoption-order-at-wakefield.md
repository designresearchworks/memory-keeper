# Story: The Adoption Order at Wakefield

## Metadata
Told: 2026-03-25T15:16:00.000Z
File: stories/the-adoption-order-at-wakefield.md
Period: 2018
People: Mina Vale, Frances Seddon, Ida Seddon
Places: Wakefield family court
Themes: adoption, family, co-parenting, responsibility, love
Connections: The Shared Umbrella After the Breakup, The Letterpress Card from Ruth
Summary: Formally adopting Frances’s daughter Ida altered Mina’s understanding of family more deeply than romance had; what she remembers is the bureaucratic plainness of the court against the scale of what was actually happening.

## Story

I adopted my ex-partner Frances’s daughter Ida in Wakefield family court on a day so administratively ordinary that it briefly seemed impossible anything of real consequence could be allowed to happen under that lighting. That, perhaps, is one of the truths of family life: the largest shifts are often processed through forms, counters, waiting areas, and people asking whether you have brought the correct identification.

I had already been acting as Ida’s parent for years by then. School runs, packed lunches, bedtime negotiations, all the ordinary and completely unglamorous repetitions by which love acquires legal pressure. The adoption order did not create the bond. But it changed the architecture around it. It made visible, in the language the state recognises, something I had already been living in my body.

Frances held my hand before we went in and let go as soon as we sat down, which felt exactly right. Some forms of love are private. Some are procedural. That morning required both.

I remember Ida afterwards mostly because she was hungry and unimpressed by the historical significance adults were trying to project onto the day. Good. Children are useful checks on sentimentality. Still, for me the order remains one of the cleanest moments of commitment in my life. Not passion. Responsibility chosen and ratified. A family made more official than romance ever manages to be.
