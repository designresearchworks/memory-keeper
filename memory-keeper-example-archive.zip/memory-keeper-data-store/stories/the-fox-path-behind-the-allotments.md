# Story: The Fox Path Behind the Allotments

## Metadata
Told: 2026-03-25T09:00:00.000Z
File: stories/the-fox-path-behind-the-allotments.md
Period: Spring 2021
People: Mina Vale, Asha Karim
Places: Leeds allotments
Themes: more-than-human, foxes, allotments, attention, urban ecology
Connections: The Public Benches Project
Summary: While cutting through the allotments at dusk, Mina and Asha gradually realised they were not following a desire path made by humans at all but a fox route, worn into the margins by another city-user with older priorities than theirs.

## Story

Asha and I used to cut behind the allotments on the assumption that we were taking a shortcut. One evening, at that useful hour when daylight has stopped arguing but night has not yet fully taken administrative control, we noticed that the path we were following was too narrow, too sly, and too consistently threaded through bramble gaps to be ours in any meaningful sense.

It was a fox path. Or at least that is what it became in our minds once the thought arrived. The route avoided puddles with more intelligence than municipal paving usually displays. It moved behind sheds, under wire, along the backs of compost bays, and between nettle stands with a confidence that made our own use of it feel faintly colonial.

We stopped talking in full sentences and started pointing instead. A tuft of rust-coloured fur caught on a splintered fence post. A gap beneath a gate that no person would bother with. The slightly sweet, rank smell of somewhere being used repeatedly by a body not ours. The city shifted register at once. What had seemed like leftover land became a corridor in a parallel transport system.

I have thought about that often since. Humans are forever congratulating themselves on discovering paths that other species have already understood perfectly well. The foxes did not need our theory. They had logistics. We were the latecomers, briefly flattered into noticing that the city has more users than the planning documents admit.
