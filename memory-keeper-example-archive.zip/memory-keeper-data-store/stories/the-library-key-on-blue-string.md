# Story: The Library Key on Blue String

## Metadata
Told: 2026-03-24T10:24:00.000Z
File: stories/the-library-key-on-blue-string.md
Period: 1999
People: Mina Vale, Mrs Frobisher
Places: Saltmere Comprehensive School library
Themes: books, school sanctuaries, minor privileges, adolescence, trust
Connections: none
Summary: Being allowed to open the school library at lunchtime with a key on a blue cord felt to Mina like a promotion into a hidden adult order. The privilege was tiny in practical terms but large in imaginative ones.

## Story

For one term at school I was entrusted with the lunchtime library key. It hung from a blue nylon cord and was accompanied by a set of instructions so repetitive that they gave the impression previous generations of children had repeatedly attempted to leave the library open, burn it down, or both.

Mrs Frobisher, the librarian, chose me because I was, in her phrase, reliable with quiet spaces. That remains one of the best compliments I have ever received. The actual task was trivial. I had to arrive five minutes before lunch, unlock the side door, switch on the strip lights, and make sure nobody took food beyond the biography shelves. But because it involved custody and sequence and a real metal key, I experienced it as a constitutional appointment.

The library itself was not grand. It smelled faintly of damp carpet tiles and old glue. The geography section had not been updated to reflect several geopolitical realities. But it offered a controlled version of solitude, which is not a small thing for an adolescent. At lunchtime the school outside became a weather system of trays, shouting, football, and hormonal miscalculation. Inside the library there were only chairs, pages, and the useful possibility of not being addressed.

I think now that Mrs Frobisher probably distributed this little authority to whichever children seemed in need of a calm perimeter. At the time I thought she had recognised something official in me. Perhaps both are true. Often the privileges that shape you are almost absurdly minor: a key, a timetable, a person older than you deciding that you can be trusted not to make noise.
