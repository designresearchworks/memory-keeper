# Story: The Rain Garden by the Council Offices

## Metadata
Told: 2026-03-25T11:16:00.000Z
File: stories/the-rain-garden-by-the-council-offices.md
Period: 2025
People: Mina Vale, council officer (unnamed)
Places: Calderford council offices
Themes: more-than-human, rain gardens, civic design, water, plants
Connections: The Public Benches Project, The Heron at the Retention Pond
Summary: A small rain garden outside the council offices felt to Mina like one of the more honest forms of civic design, because it openly admitted water, plants, and maintenance into the same sentence.

## Story

Outside the council offices in Calderford there is now a small rain garden where there used to be an area of sulking paving and occasional puddle resentment. I like it disproportionately. Perhaps because it is one of the few civic interventions honest enough to say, in physical form, that water will arrive and we had better make some sort of social arrangement with it.

The planting is not dramatic. Sedge, iris, a few shrubs tolerant of periodic saturation, and a basin shape that invites runoff rather than insisting on immediate expulsion. You can almost see the shift in philosophy. Not control at all costs, but slowed accommodation.

A council officer once apologised to me that it looked messy in winter. I told him that mess was part of its credibility. Rain gardens should not resemble decorative denial. They are infrastructural wetlands in miniature, and the more they reveal that role, the more trustworthy they become.

Perhaps that is what I like most. The thing joins civic language, hydrology, horticulture, and care labour without pretending they are separable domains. It is a tiny bureaucratic marsh by the photocopier state. Which sounds insulting until you realise it may also be the future.
