# Story: The Ceramic Fox on the Mantelpiece

## Metadata
Told: 2026-03-24T11:52:00.000Z
File: stories/the-ceramic-fox-on-the-mantelpiece.md
Period: 2017
People: Mina Vale, Noor Hamdi
Places: Calderford
Themes: home life, objects, breakups beginning, domestic symbolism, silence
Connections: none
Summary: A ceramic fox bought impulsively and displayed for years became, late in Mina and Noor’s relationship, a strange stand-in for all the things in a home that survive changes in feeling longer than one expects.

## Story

We bought a ceramic fox at a craft market because Noor said it looked simultaneously sly and apologetic. This was accurate. It had one ear slightly lower than the other and the glaze pooled around the paws in a way that made it seem perpetually caught in an alibi.

For years it lived on the mantelpiece without attracting much interpretation. Then, towards the quieter and more difficult end of our relationship, I became absurdly aware of it. Domestic objects do this. They remain in position while the emotional weather shifts around them and thereby start to look like witnesses.

The fox was not meaningful in itself. That is important. It had not been a gift marking a milestone or a treasured heirloom. It was a small thing we had once both found funny. Which is precisely why it became useful to memory. Large symbols are almost too obedient. A ceramic fox can hold ambiguity better.

I remember one evening when Noor and I were sitting in the same room reading separate things and not quite speaking enough. I looked up and saw the fox and had the peculiar thought that it still belonged equally to a version of us that was no longer present. Nothing dramatic followed. No conversation was precipitated. But I think that was when I first recognised that a relationship can begin ending before either person is ready to name the fact out loud.

After we separated, Noor told me to keep the fox. It is still on a shelf in my study. Less witness now than remnant.
