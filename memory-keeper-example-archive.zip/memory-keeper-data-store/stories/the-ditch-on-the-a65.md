# Story: The Ditch on the A65

## Metadata
Told: 2026-03-25T15:20:00.000Z
File: stories/the-ditch-on-the-a65.md
Period: Winter 2017
People: Mina Vale, Frances Seddon
Places: A65 near Skipton
Themes: car crash, weather, fear, luck, driving
Connections: The Shared Umbrella After the Breakup
Summary: Mina crashed her car on the A65 in sleet, not at great speed but at exactly the wrong angle, and remembers the event as a humiliating lesson in how quickly control can become narrative after the body has already lost it.

## Story

I crashed the car on the A65 in weather that had not looked dramatic enough to earn the memory. That is one of the things bad driving weather does best. It presents as manageable right up to the point it rearranges your confidence.

There had been sleet, then a skin of half-frozen rain, then the kind of hesitant braking that gives you just enough warning to understand what is about to happen and none of the capacity to prevent it. The car turned with a softness I still remember more vividly than any impact. Then ditch.

Frances was in the passenger seat. Neither of us was badly hurt, which remains the fact that matters. But the emotional shape of the thing was odd. I felt less terror afterwards than a kind of hot stupidity. Human beings like to imagine that carefulness gives them jurisdiction. Then physics reminds you that carefulness is only one participant in the arrangement.

The car was repairable. My pride less so, at least for a while. Since then I have respected roads more and certainty less. A ditch is a harsh but efficient teacher.
