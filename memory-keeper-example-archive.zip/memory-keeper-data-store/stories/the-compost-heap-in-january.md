# Story: The Compost Heap in January

## Metadata
Told: 2026-03-25T09:04:00.000Z
File: stories/the-compost-heap-in-january.md
Period: January 2022
People: Mina Vale
Places: Mina’s garden, Leeds
Themes: more-than-human, compost, seasonality, gardening, material cycles
Connections: The Memio Experiment
Summary: Turning the compost in winter, Mina became briefly fascinated by the heat rising from decay and by the fact that the most visibly dead part of the garden was also, in process terms, the busiest.

## Story

I turned the compost heap in January partly out of horticultural guilt and partly because a neighbour had said, with the authority of people who know worms personally, that winter is precisely when the heap deserves not to be ignored. The garden looked mostly finished at that point. Damp stems, exhausted beds, a lawn with the expression of wet cardboard. Nothing in it suggested fervour.

Then I put the fork in.

The heat was what startled me. Not dramatic heat, not a furnace, but a distinct pocket of warmth rising from peelings, stems, paper, coffee grounds, and whatever else had quietly been entering decomposition under the pretence of being waste. Steam lifted. Things that looked static were in fact extremely busy. There is something corrective in being reminded that visible decline and active transformation are not opposites.

I stood there in a hat and old gloves, stirring rot with surprising reverence. Compost is one of the few human technologies that teaches humility without requiring a manifesto. You put in what you thought was over. It returns, eventually, as structure for something else.

That may sound hippyish, and perhaps it is. But it is also just physically true. The heap was not symbolic first and material second. It was a metabolic argument happening in a wooden bin. The garden knew this already. I was the one catching up.
