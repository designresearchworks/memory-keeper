# Story: The Argument in Carriage B

## Metadata
Told: 2026-03-25T15:28:00.000Z
File: stories/the-argument-in-carriage-b.md
Period: 2022
People: Mina Vale, train passenger (unnamed), conductor (unnamed)
Places: London to Leeds train
Themes: anger, trains, public shame, fatigue, temper
Connections: The Bad Panel Question
Summary: After months of illness, work strain, and bad sleep, Mina finally lost her temper on a train in a way she still regrets: not because anger is always wrong, but because public rage leaves such a poor residue of self.

## Story

I lost my temper on a train in Carriage B somewhere north of Peterborough and have replayed it far more often than the occasion deserves. The proximate cause was a man speaking at full volume on speakerphone in one of the quiet coaches, then acting as though the entire carriage had personally insulted him when the conductor asked him to stop. The deeper cause was that I was tired in ways I had not properly acknowledged.

Cancer treatment had finished, technically. Work had resumed, technically. Life was functioning, technically. But I had become one of those brittle people for whom small civic violations begin to feel cosmically targeted.

So when the man started in on the conductor, I intervened. Not brilliantly. Not with cool moral authority. With heat. My voice went sharper and louder than I intended, and suddenly I was no longer a person defending shared norms but another public difficulty in the aisle.

The conductor handled it better than I did. That, too, is part of the shame. I was right about the principle and wrong about the performance. Anger is not always a failure, but losing the shape of yourself inside it often is. What remained afterwards was not triumph, only adrenaline and the sour knowledge that exhaustion had been speaking through my mouth.
