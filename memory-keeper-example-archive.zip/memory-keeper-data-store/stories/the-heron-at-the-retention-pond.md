# Story: The Heron at the Retention Pond

## Metadata
Told: 2026-03-25T09:36:00.000Z
File: stories/the-heron-at-the-retention-pond.md
Period: Autumn 2024
People: Mina Vale, Eli Barrett
Places: Retail-park retention pond, Leeds
Themes: more-than-human, herons, retention ponds, suburban ecology, attention
Connections: The Public Benches Project
Summary: A heron standing beside a stormwater retention pond behind a retail park looked, to Mina, less like a symbol of wildness than a patient professional making use of the drainage compromises of late capitalism.

## Story

There is a retention pond behind a retail park on the edge of Leeds that exists, officially, to manage stormwater and, unofficially, to collect trolley fantasies and windblown wrappers. Eli and I had parked nearby for something forgettable when we saw a heron standing at the pond edge with that prehistoric stillness herons weaponise so effectively.

The visual juxtaposition was almost rude. Chain coffee, signage, logistics sheds, and there among them a bird built for marsh patience. But the more I looked, the less absurd it seemed. The pond held water. Water held small life. The heron had run the numbers and found the site satisfactory. No romance required.

I think we are often too quick to read such moments as either tragic degradation or redemptive nature-return. Both framings centre human feeling rather too neatly. The heron was not there to reassure us that the world persists. It was there because a drainage basin, however compromised, had entered a food web.

That felt more interesting than symbolism. Infrastructure leaks into ecology constantly. Ditches, culverts, verges, ponds, embankments. Other species make practical use of our engineering leftovers. Sometimes they do it with such composure that the whole planning regime starts to look like an accidental support service.
