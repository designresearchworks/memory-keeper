# Story: The Lichen on the Bench Slat

## Metadata
Told: 2026-03-25T10:40:00.000Z
File: stories/the-lichen-on-the-bench-slat.md
Period: 2025
People: Mina Vale
Places: Calderford riverside bench
Themes: more-than-human, lichen, benches, slow time, public space
Connections: The Public Benches Project
Summary: Noticing a scatter of lichen on the underside of a riverside bench slat, Mina was reminded that even the furniture she helped think about enters longer, stranger timescales than use alone suggests.

## Story

I was crouched beside a riverside bench checking a loose fixing when I noticed a scatter of lichen beginning on the underside of one wooden slat. It was the kind of detail you only see when maintenance or curiosity has already made you physically ridiculous in public. Pale green-grey, delicate, slow, almost shy.

Benches are usually discussed in terms of users. Who sits, who rests, who feels welcome, who lingers. All of that matters. But the lichen made another point. Public furniture also enters weather, spore, damp, river mist, bird feet, and the long patient chemistry of exposure.

I liked the thought that a bench might belong, in however minor a sense, not only to civic design and human need but to colonisation by forms of life operating on wholly different tempo. The slat was seat, support, surface, habitat, and substrate at once.

This did not make the maintenance issue disappear. Rotten wood remains rotten wood. But it did complicate the usual language of wear and tear. Sometimes what institutions call deterioration is partly also enrolment into ecological time. The bench was becoming something more than a completed object. It was entering relations.
