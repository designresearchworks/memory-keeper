# Story: The Museum of Failed Signs

## Metadata
Told: 2026-03-24T12:52:00.000Z
File: stories/the-museum-of-failed-signs.md
Period: 2022
People: Mina Vale, Asha Karim
Places: Manchester
Themes: design humour, wayfinding, work ideas, friendship, cities
Connections: The Public Benches Project
Summary: Mina and Asha developed a half-serious idea for an exhibition made entirely of confusing or contradictory public signs. The concept never became a project, but the conversation captured how they think together.

## Story

Asha and I once spent an afternoon collecting photographs of terrible public signs and, by the time we got to the fourth contradictory wayfinding arrow, had developed what we insisted was a serious curatorial idea called The Museum of Failed Signs.

The premise was simple. Cities are full of language pretending to clarity while generating mild chaos. Entrance signs that indicate two opposite directions. Temporary notices laminated into permanence. Councils apologising for inconvenience in fonts large enough to become inconvenient themselves. We wanted, half as joke and half as method, to assemble these into a public exhibition about the rhetoric of guidance.

Nothing came of it institutionally. This was probably wise. Yet the idea has stayed with me because it emerged from the most enjoyable kind of professional friendship: one built on shared irritation becoming inquiry. Asha is one of the few people with whom I can move, in the space of ten minutes, from laughing at a sign to discussing what authority sounds like when it is uncertain.

We ended the day in a café surrounded by photographed arrows pointing nowhere useful and felt, for a while, as though we had stumbled onto an entire understudied branch of civic literature. Perhaps we had. Failed signs are among the purest artefacts of institutional aspiration. They want so badly to be enough.

I still harbour some affection for the exhibition title. Most people in design are better at displaying success. Failure often has sharper typography.
