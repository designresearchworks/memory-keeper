# Story: The Married Ceramicist

## Metadata
Told: 2026-03-25T15:04:00.000Z
File: stories/the-married-ceramicist.md
Period: 2007
People: Mina Vale, Rafe Bell
Places: Glasgow School of Art annexe, Rafe’s studio flat
Themes: affair, art school, desire, bad decisions, power
Connections: The Basement Darkroom, The Girl with the Silver Shaved Head
Summary: Mina’s affair with a married ceramicist a few years older than her was not, even at the time, something she mistook for wisdom; what she remembers now is the atmosphere of adult permission it seemed to offer and the hollowness underneath.

## Story

For a while, during my final year at art school, I was having an affair with a married ceramicist called Rafe Bell. Even writing that sentence now, I can feel the stale glamour trying to rise off it like heat from a radiator. It was never as grand, or as inevitable, as the phrase affair encourages people to believe.

Rafe was older, clever, and artistically serious in a way that appealed to the part of me still confusing attention with recognition. He spoke as though every object had moral weather in it. He also had a wife in Dundee, which ought to have been a sufficiently clarifying fact. It was clarifying morally. It was not clarifying behaviourally, at least not for me then.

What I think I wanted was not him exactly but the atmosphere around him: maturity, permission, the sense that life could be improvised in more dangerous colours than the ones I had been using. Affairs promise that sort of compression. They make urgency feel like depth.

It did not last. Of course it did not. The ending was less dramatic than the beginning had pretended to be. What remains is the embarrassment of having once mistaken complication for seriousness. There are lessons you learn in theory and then learn again with your clothes on.
