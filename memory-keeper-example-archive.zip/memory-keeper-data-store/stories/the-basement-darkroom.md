# Story: The Basement Darkroom

## Metadata
Told: 2026-03-24T10:40:00.000Z
File: stories/the-basement-darkroom.md
Period: 2005
People: Mina Vale, Luca Fenner
Places: Glasgow School of Art annexe
Themes: art school, photography, craft, young adulthood, romance
Connections: The Accordion on the Coach to Prague
Summary: At art school, Mina spent evenings in a basement darkroom learning how much patience analogue photography demanded and how attractive competence looked under a red safelight. The story captures the tactile seriousness of making things slowly.

## Story

At art school I spent a period convinced that analogue photography would save me from the vagueness of my own taste. Digital cameras, at that time, still felt slightly tinny and immediate. Film at least imposed a procedure. You had to decide, expose, develop, wait. I was attracted to the discipline of it, though discipline in my case often wore the clothes of aesthetic preference.

The darkroom was in the basement of an annexe building in Glasgow and smelt permanently of chemicals, dust, and damp concrete. Red safelights make everyone look briefly mythic, which cannot have helped the emotional atmospherics. Luca Fenner, who knew what he was doing, moved around the trays and enlarger with a level of competence I found almost indecently appealing.

There is a particular magic to watching an image emerge in developer. It is not really magic, of course, but chemistry has always benefitted from theatricality. A blank-looking sheet acquires shadows, then a face, then detail. You stand there holding tongs as though that makes you part of the revelation.

Most of my prints were mediocre. I framed too much, then too little. My contrast was often wrong. But the process stayed with me because it made visible the advantage of slowness. You could not bully the paper into becoming ready sooner. You had to let the thing appear. This is useful knowledge in almost every domain, though unfortunately acquiring it once does not mean you stop behaving as if urgency might eventually outrun reality.
