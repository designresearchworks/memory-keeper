# Story: The Cafe with the Orange Formica

## Metadata
Told: 2026-03-25T15:00:00.000Z
File: stories/the-cafe-with-the-orange-formica.md
Period: 2006, art-school years
People: Mina Vale, Mags Ritchie, customers (unnamed)
Places: The Saucer and String cafe, Glasgow
Themes: art school, cafe work, young adulthood, service work, observation
Connections: The Call Centre Voice, The Warehouse with the Painted Floor
Summary: While at art school, Mina worked in a cafe with orange Formica tables and learned more than she expected about class performance, repetition, and how much of adulthood is built from carrying plates while overhearing the truth.

## Story

During art school I worked four days a week in a cafe called The Saucer and String, which had orange Formica tables, inconsistent soup, and the sort of regulars who believed that finding the same seat every morning constituted a social right. I loved it more than I admitted at the time.

The work itself was ordinary enough: milk steaming, tray carrying, wiping rings from laminated surfaces, learning how to smile without committing to conversation. But cafes are observational goldmines. People arrive slightly under-defended. They tell on themselves in what they order, whether they stack plates, how they speak to whoever is behind the till, whether they say sorry to chairs.

Mags Ritchie, who managed the place with volcanic efficiency, taught me how to carry three bowls of soup at once and how to identify customers who wanted warmth from those who wanted obedience. That distinction has lasted. Service work gives you a close view of hierarchy in its most domestic costume.

Art school fed my theories. The cafe fed my eye. I do not think the two educations were separate. By the time I went home smelling of coffee grounds and fryer oil, I often felt I had spent the day studying composition by other means: gesture, class, repetition, silence, surface, hunger.
