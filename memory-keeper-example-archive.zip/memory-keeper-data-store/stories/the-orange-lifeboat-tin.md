# Story: The Orange Lifeboat Tin

## Metadata
Told: 2026-03-24T10:04:00.000Z
File: stories/the-orange-lifeboat-tin.md
Period: Early 1990s
People: Mina Vale, Adrian Vale, Theo Vale
Places: Saltmere harbour, Vale family kitchen
Themes: childhood collections, saving objects, seaside towns, father-daughter rituals
Connections: The Day the Pier Speaker Crackled
Summary: Mina and her father developed a habit of dropping spare coins into an orange RNLI collection tin shaped like a lifeboat. The object became less about charity in the abstract than about sound, ritual, and the comforting idea that small repeated acts could keep disaster offshore.

## Story

My father kept an orange RNLI collection tin on the kitchen dresser. It was shaped like a lifeboat in only the most symbolic sense. Nobody, looking at it honestly, would have mistaken it for a seaworthy vessel. It was a metal box with a slot. But because it was orange and had RNLI printed on the side, I regarded it as a member of the emergency services.

Whenever we came back from Saltmere harbour with change in our pockets, my father would let me post a coin into it. The sound mattered. Pennies made a thin, unsatisfactory click. Fifty pence pieces felt magnificent. If there was a pound coin available, the whole event acquired almost ceremonial weight. My father would say, very seriously, that we were helping to keep people from being washed away. I believed him completely.

In my head the mechanism was simple. Storm arrives, boat goes out, because I put 20p in the tin. Cause and effect. It made the sea feel less arbitrary. North Sea weather was always slightly too large for the town, and the grown-ups spoke about it with that familiar coastal mixture of respect and routine. The lifeboat tin was my way of participating in the order of things.

I do not know where the tin ended up. It must have disappeared in one clear-out or another. But I can still remember the exact resistance of the slot and the way my father always made space for the act, never hurrying it. He was not sentimental in a conspicuous way. That was part of his method. He allowed objects to carry feeling on his behalf.
