# Story: The Warehouse with the Painted Floor

## Metadata
Told: 2026-03-24T10:48:00.000Z
File: stories/the-warehouse-with-the-painted-floor.md
Period: 2006
People: Mina Vale, Tobias Reed, Sana Qureshi
Places: Glasgow
Themes: student housing, creative life, mess, friendship, young adulthood
Connections: The Basement Darkroom
Summary: Mina lived for a year in a converted warehouse flat whose painted concrete floor was always cold and always somehow social. The story is about communal living, improvised adulthood, and the affection that can attach itself to impractical spaces.

## Story

For one year I lived in a converted warehouse flat with a painted concrete floor that was visually excellent and thermally absurd. It looked exactly like the kind of place young creative people are supposed to inhabit in films made by those who have never tried to heat one. In winter you could feel the cold through chairs.

There were four of us in the flat, and the central room was too large to furnish convincingly, so everything happened in islands: one lamp by the sofa, one table near the kitchen, a desk by the window, bicycles against the wall. This made ordinary evenings feel faintly theatrical, as though each person was lit for their own subplot.

Tobias painted huge canvases in the corridor because they would not fit anywhere else. Sana cooked as though scarcity were merely an organisational challenge. I was still learning the difference between liking the idea of adulthood and carrying it out reliably. The flat helped because it made life public. If you had forgotten to buy milk, everyone knew. If you were heartbroken, it became acoustically available.

I remember one evening when friends came over and someone spilled red wine on the floor. There was a brief silence as we all looked down, then relief when it became obvious the floor, already scarred and streaked with previous ambitions, had merely absorbed the event into its character.

That was the flat’s real gift. It did not ask for perfection. It looked better once marked. Some spaces flatter you by seeming to improve when used hard. I suspect many people mistake that sensation for destiny.
