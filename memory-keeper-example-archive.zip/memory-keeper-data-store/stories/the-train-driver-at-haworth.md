# Story: The Train Driver at Haworth

## Metadata
Told: 2026-03-25T15:40:00.000Z
File: stories/the-train-driver-at-haworth.md
Period: Autumn 2023
People: Mina Vale, Ellen Mowbray
Places: Haworth, Keighley and Worth Valley Railway, Bronte country
Themes: Haworth, Bronte country, train driver, women, romance, landscape
Connections: none
Summary: A trip to Haworth in search of Bronte atmosphere became, unexpectedly, the beginning of a short and sincere love with a woman who drove heritage trains and looked at the moors as if they were colleagues rather than scenery.

## Story

I went to Haworth because I wanted, in a slightly embarrassing but genuine way, to feel some Bronte weather for myself. Not literary tourism exactly. More a desire to stand in a place where landscape and sentence had once taken one another seriously. The moor did its part. So, unexpectedly, did the train driver.

Her name was Ellen Mowbray, and she drove on the heritage line with the calm focus of someone who understood machinery as relationship rather than domination. We got talking because I asked a question about braking on the incline that was only half about braking. She answered without flirtation first, which made the later flirtation much more persuasive.

What I fell for was not merely her face, though that would have been reason enough. It was the way she looked at the surrounding country. Not as backdrop, not as romance package, but as working weather, gradient, line condition, sheep trouble, historical atmosphere, and beauty all at once. That combination felt very close to my own mind.

We did have a love affair of sorts afterwards, brief and entirely real. It did not become a lifelong thing. Not everything important does. But Haworth remains charged for me because the moor gave me one kind of solemnity and Ellen another. Literature on the hill. Diesel below it. Desire arriving between them.
