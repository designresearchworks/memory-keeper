# Story: The Worms After the Downpour

## Metadata
Told: 2026-03-25T09:40:00.000Z
File: stories/the-worms-after-the-downpour.md
Period: October 2023
People: Mina Vale
Places: Leeds pavement after rain
Themes: more-than-human, worms, rain, pavements, care
Connections: The Compost Heap in January
Summary: After heavy rain, Mina found herself repeatedly moving stranded worms off the pavement with a leaf, embarrassed by the tenderness of it but unwilling to stop.

## Story

After a heavy downpour I walked to the corner shop and spent much of the journey stooping to move worms off the pavement with a sycamore leaf. This is not behaviour I had planned into the afternoon. It emerged from proximity, dampness, and the intolerable sight of soft bodies stranded on drying concrete while people in trainers threaded around them unconcerned.

I am aware this can sound absurdly earnest. Perhaps it was. Yet the thing itself was practical. Worms on pavements after rain are caught between systems: breathable soil behind them, desiccating exposure ahead. A small intervention with a leaf shifts the odds. That is all.

What interested me, once I had accepted the role, was how quickly care can become situational rather than ideological. I was not making a statement about life. I was enacting a very local refusal to step over preventable trouble. The worms did not know, and the pavement certainly did not. But attention had become manual.

By the time I got to the shop I was muddy and faintly self-conscious. Even so, I think there was something clarifying in the sequence. Ethics are often discussed in grand vocabulary. Sometimes they are just damp knees, a leaf, and deciding the tiny body in front of you counts enough to inconvenience your route.
