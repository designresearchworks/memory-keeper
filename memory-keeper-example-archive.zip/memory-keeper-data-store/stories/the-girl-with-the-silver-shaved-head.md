# Story: The Girl with the Silver Shaved Head

## Metadata
Told: 2026-03-25T15:08:00.000Z
File: stories/the-girl-with-the-silver-shaved-head.md
Period: 2006
People: Mina Vale, Mara Quinn
Places: Glasgow art-school party, Mara’s flat
Themes: queer desire, art school, women, identity, awkward tenderness
Connections: The Married Ceramicist, The Red Coat on the Footbridge
Summary: Trying to sleep with women during art school was, for Mina, less a cleanly declared identity than a series of earnest, awkward, often revelatory encounters, none more memorable than a night with a girl called Mara whose shaved silver head made her seem braver than anyone Mina knew.

## Story

At art school I tried, somewhat belatedly and without much ideological neatness, to sleep with women. I say tried because the process felt less like arriving at an identity than like crossing a sequence of badly lit thresholds while carrying too much self-consciousness.

The person I remember most clearly is Mara Quinn, who had a silver shaved head and the kind of confidence that made everyone else look over-rehearsed. We kissed at a party first, then later ended up in her flat with the sort of mutual seriousness that belongs to situations where both people suspect more may be at stake than technique can comfortably handle.

What I remember is tenderness, confusion, and the immediate collapse of several assumptions I had not known I was still carrying. Bodies are not ideas, and queer desire, at least in my case, did not arrive as a manifesto. It arrived as embarrassment, curiosity, relief, and a feeling that a door in the house of my own life had opened onto a corridor I should have recognised sooner.

Mara and I did not become a couple. That is not the point of the story. The point is the scale of internal rearrangement that can happen in one ordinary room with someone who does not require you to pretend you already know yourself.
