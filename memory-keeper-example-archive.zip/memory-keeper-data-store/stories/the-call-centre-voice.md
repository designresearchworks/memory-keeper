# Story: The Call Centre Voice

## Metadata
Told: 2026-03-24T10:56:00.000Z
File: stories/the-call-centre-voice.md
Period: 2008
People: Mina Vale, Helen Draper
Places: Leeds
Themes: first jobs, performance of self, workplace culture, voice, survival
Connections: The Warehouse with the Painted Floor
Summary: Working briefly in a call centre taught Mina that the voice one uses for paid reassurance is both a practical tool and a mild estrangement from oneself. The job was not terrible, but it was clarifying in the way temporary jobs often are.

## Story

After university I worked for six months in a call centre in Leeds handling customer service queries for a home-appliance company. This was not my imagined destiny, but then very few people imagine themselves into headset employment with any conviction.

The first thing they trained us to do was alter our voices. Not entirely, of course. That would have been theatrical. But enough. We were meant to sound calm, bright, and endlessly available to the emotional weather of strangers with malfunctioning washing machines. Helen Draper, who supervised our team, called this finding your service register. I understood what she meant. There are tones one can wear for money.

What unsettled me was how quickly the register became accessible on command. Someone would ring furious about a delayed repair and I would hear myself becoming measured and generous, as though I had been grown in a customer-care greenhouse. None of it was insincere exactly. I did want the person to be helped. But the gap between feeling and performed helpfulness fascinated me.

Temporary jobs often teach you something oddly central because they strip away any fantasy that the lesson itself is the point. In that office I learned how much of adult life runs on managed affect: voices calibrated to soothe, reassure, redirect, or survive. I also learned I did not want to do it indefinitely. Both forms of knowledge were useful. One paid the rent; the other became direction.
