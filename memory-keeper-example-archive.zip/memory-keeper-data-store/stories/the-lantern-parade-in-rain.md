# Story: The Lantern Parade in Rain

## Metadata
Told: 2026-03-24T12:00:00.000Z
File: stories/the-lantern-parade-in-rain.md
Period: 2018
People: Mina Vale, Asha Karim, children of Calderford (unnamed)
Places: Calderford
Themes: community events, weather, design work, public joy, fragility
Connections: The Public Benches Project
Summary: A community lantern parade that had been painstakingly designed around light and atmosphere had to proceed in stubborn rain. The event still worked, but differently, teaching Mina something about designing for adaptation rather than ideal conditions.

## Story

We spent weeks planning a community lantern parade in Calderford and, like fools, built much of our emotional expectation around dry weather. The event was beautiful in theory: hand-made lanterns, dusk, a procession along the river path, music, children feeling briefly part of something ceremonial. In practice, by late afternoon, rain had arrived with persistence rather than drama.

There is a special despair reserved for organisers watching weather invalidate aesthetics. Tissue paper darkens. Candle plans become liability. Volunteers begin using the phrase we'll just see in tones that mean the opposite.

Asha Karim, who was far better at public projects than I was at that point, made the crucial decision that the parade should proceed in altered form rather than as a damaged version of itself. Battery lights replaced flames. The route was shortened. Marshals acquired extra umbrellas and a degree of heroic wetness.

What happened was not what we had designed, but it was not lesser. The rain made the lantern colours denser. People huddled closer. The children treated the whole thing as evidence of seriousness: if everyone was willing to march in this, it must matter.

That evening altered my understanding of design work in the public realm. Ideal conditions are a fantasy category. The real question is whether a form can survive contact with weather, delay, mood, and compromised materials. Beauty that depends on perfection is often just control in evening dress.
