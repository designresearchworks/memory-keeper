# Story: The Letterpress Card from Ruth

## Metadata
Told: 2026-03-24T14:00:00.000Z
File: stories/the-letterpress-card-from-ruth.md
Period: 2026
People: Mina Vale, Ruth Vale
Places: Leeds
Themes: mother-daughter relationships, cards, language, family affection, small gifts
Connections: none
Summary: A short card from Mina’s mother, written in sparse but exact language, meant more to her than more elaborate gestures often do. The story is about the family style of affection through understatement.

## Story

My mother recently sent me a letterpress card that said, simply, Thinking of you. Proud of what you are making. Love, Mum. The card itself was plain cream stock with navy type. Nothing decorative beyond the fact of its having been chosen and posted.

This affected me more than messages many times longer. Partly because my mother is not extravagant with praise. Not withholding, exactly, just precise. She does not scatter affirmation to improve the atmosphere. Which means when it arrives, it has usually been weighed.

Family feeling in our house has rarely been operatic. It comes in food, in lifts to stations, in checking whether you reached home, in practical questions that turn out to contain concern. A card like that therefore carries the force of translation. The feeling has been rendered into language, however briefly.

I put it on the mantelpiece for a week and then moved it to my desk because the sight of it there changed the room's weather slightly for the better. This is one of the underappreciated powers of written words in physical form. They remain where text messages vanish into sequence.

Perhaps that is another reason I care about archives. Not because everything important must be preserved, but because some kinds of care become more believable when they can still be picked up tomorrow.
