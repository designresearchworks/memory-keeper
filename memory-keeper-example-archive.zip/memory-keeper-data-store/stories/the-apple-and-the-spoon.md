# Story: The Apple and the Spoon

## Metadata
Told: 2026-03-25T15:36:00.000Z
File: stories/the-apple-and-the-spoon.md
Period: 2005, first year at art school
People: Mina Vale
Places: Glasgow student flat
Themes: eating disorder, art school, body image, control, young adulthood
Connections: The Basement Darkroom, The Girl with the Silver Shaved Head
Summary: Mina’s eating disorder episode at art school was less theatrical than people imagine such things to be; what she remembers is the smallness of the rituals and the way self-starvation masqueraded as discipline and aesthetic seriousness.

## Story

When I had an eating disorder at art school, very little about it looked dramatic from the outside. That is one reason it lasted as long as it did. There were no cinematic collapses, no grand confessions, no cleanly visible crisis. There were just rituals: an apple cut too precisely, yoghurt measured by fear rather than appetite, coffee where lunch ought to have been, and a spoon that seemed to acquire absurd moral weight.

At the time I would not have called it an eating disorder. I would have called it being careful, or trying to get a grip, or not wanting to become sloppy. Those words were useful because they made self-erasure sound like discipline. Art school did not cause it, but it offered enough visual culture, enough bodily comparison, enough aestheticised thinness for the illness to dress itself persuasively.

What I remember most is not hunger itself but the narrowing. Life gets smaller very quickly once food becomes an argument. Rooms shrink to mirrors and cupboards. Friendships become harder to inhabit honestly. Thinking turns both obsessive and stupid.

Recovering was not one clean moment. It was a sequence of embarrassingly ordinary concessions to life: soup, toast, eating with other people, admitting that a body is not a project to be subdued into brilliance. I do not romanticise the lesson. I am only grateful I outlived the logic.
