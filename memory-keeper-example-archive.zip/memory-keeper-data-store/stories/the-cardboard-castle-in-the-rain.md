# Story: The Cardboard Castle in the Rain

## Metadata
Told: 2026-03-24T10:08:00.000Z
File: stories/the-cardboard-castle-in-the-rain.md
Period: Autumn 1994
People: Mina Vale, Leah Porter, Ruth Vale
Places: Vale family garden, Saltmere
Themes: childhood projects, weather, friendship, failure, imagination
Connections: The Orange Lifeboat Tin
Summary: A painstaking cardboard castle built in the garden with her friend Leah dissolved in a sudden rainstorm before either girl was willing to admit the project had been badly conceived from the start. Mina remembers less the disappointment than the stubborn loyalty they briefly showed to a structure that was obviously turning back into pulp.

## Story

Leah Porter and I once spent an entire afternoon building a castle out of cardboard boxes in my parents' garden. We used the side panels of a washing-machine box for the walls and a cereal packet for what we insisted on calling the drawbridge. We had no moat, no roof, and no coherent architectural principles, but at the age we were I considered the enterprise sound.

The trouble with cardboard, as it turns out, is weather. The trouble with children, similarly, is optimism. We noticed the first spots of rain and chose to interpret them as temporary. Then we noticed the corner towers beginning to bow inwards and decided this was atmospheric. By the time the front wall gave way with a long tired sigh, we were both too invested to concede reality. Leah suggested that real castles also suffered damage and that ours was simply becoming historical.

My mother watched this from the back door with the expression adults have when they can see the entire lesson in advance. She did not intervene. I am grateful for that. There are some failures that need to be permitted enough time to collapse under their own logic.

Eventually the drawbridge detached itself and floated across the grass like a stranded biscuit. At that point even we accepted defeat. What remains with me is not really the sadness of the thing, because there was not much sadness. It is the seriousness with which we defended a ridiculous project for several minutes after its impossibility had become undeniable. That may be a childish trait, but it is not one children monopolise.
