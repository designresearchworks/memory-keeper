# Story: The Red Coat on the Footbridge

## Metadata
Told: 2026-03-24T10:28:00.000Z
File: stories/the-red-coat-on-the-footbridge.md
Period: Around 2001
People: Mina Vale, Euan Mercer
Places: Railway footbridge, Saltmere
Themes: first love, teenage longing, railway towns, missed timing, weather
Connections: The Library Key on Blue String
Summary: A brief teenage romance acquired disproportionate emotional significance because it mostly consisted of waiting for one another in the wrong places at almost the right times. The image Mina keeps is of a red coat on a railway bridge in sleet.

## Story

My first proper teenage fixation was on a boy called Euan Mercer, who had the kind of face that suggested constant inward weather and the useful habit of reading novels on buses. We were never exactly together, though for several months we occupied that intermediate state in which every exchange is over-interpreted and every logistical failure acquires tragic dimensions.

The most characteristic episode involved the railway footbridge in Saltmere. We had, through means now lost to history, agreed to meet there after school. It was sleeting. I arrived early. Then the train from Whitbridge came through and everyone had to stand back from the railings because the wind off it was filthy. I waited perhaps fifteen minutes and decided he was not coming. As I turned away I saw, at the far end of the bridge, a figure in the red coat he always wore.

The trouble was that by then we were separated by the incoming crowd and my own wounded determination. I did what only a teenager could do with such confidence: I chose not to call out because if he had really wanted to see me, he would somehow have already arranged to be standing beside me.

This was nonsense, obviously. He was there. I was there. A system had failed and neither of us corrected it. But the image remains oddly strong: red coat, wet metal, sleet moving sideways, and a conviction that timing had moral content. I do not remember what happened between us afterwards in much detail. I remember instead the architecture of almost-meeting, which is often what adolescence is built from.
