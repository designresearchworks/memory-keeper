# Story: The Shared Umbrella After the Breakup

## Metadata
Told: 2026-03-24T12:16:00.000Z
File: stories/the-shared-umbrella-after-the-breakup.md
Period: 2019
People: Mina Vale, Noor Hamdi
Places: Leeds station
Themes: breakup, kindness, rain, ambiguity, adult endings
Connections: The Ceramic Fox on the Mantelpiece
Summary: Shortly after their breakup, Mina and Noor found themselves sharing an umbrella from the station because neither wanted to perform hostility. The moment was awkward, generous, and impossible to classify neatly.

## Story

A few weeks after Noor and I broke up, we happened to arrive on the same train into Leeds and discovered, on stepping onto the concourse, that it was raining hard enough to cancel pretence. I had no umbrella. Noor did.

There are moments after a breakup in which the emotional script seems unavailable. Too much kindness looks misleading. Too much coldness looks theatrical. We stood near the station doors for a second assessing weather and one another, then Noor simply opened the umbrella and said come on.

So we walked together through the rain as if carrying on a role for which the contract had technically expired. The umbrella was too small. Our bags kept colliding. We made conversation that was neither intimate nor entirely generic, which may be the hardest conversational register of all.

What stayed with me was not sadness exactly, though there was some. It was the peculiar decency of the thing. Relationships do not end by turning all previous tenderness false. Sometimes there is still enough care left for logistics, even when the larger structure is gone.

At the corner where our routes separated, Noor said keep the umbrella till next week and handed it to me before I could refuse. That was both practical and devastating in a small, disciplined way. Adult endings are often less about scene than about objects changing custody under poor weather.
