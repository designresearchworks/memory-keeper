# Story: The Accordion on the Coach to Prague

## Metadata
Told: 2026-03-24T10:36:00.000Z
File: stories/the-accordion-on-the-coach-to-prague.md
Period: Spring 2004
People: Mina Vale, Carys Bennett, Mr Doyle
Places: Prague, school trip coach
Themes: school trips, Europe, awkward travel, music, adolescence
Connections: The Red Coat on the Footbridge
Summary: A school trip to Prague was improved and slightly deranged by a fellow pupil who had inexplicably brought an accordion and kept playing fragments of songs at border crossings. Mina remembers the trip less for the city than for the surreal social texture of getting there.

## Story

On the school trip to Prague, someone brought an accordion.

Even now I admire the confidence this required. A coach full of sixth-formers is not an environment that naturally rewards sincere musical initiative. Yet Carys Bennett, who was built from sterner material than the rest of us, appeared at departure with a full-size accordion in a black case and treated the matter as self-evidently normal.

The journey took an age. Coaches to Europe in those days seemed designed to prove that geography was punishment. We spent long stretches in a stale half-sleep while teachers counted us repeatedly and border officials looked into the vehicle with expressions suggesting they regretted civilisation. At several points, usually when morale was lowest, Carys would produce the accordion and play something halfway between a sea shanty and a folk tune. Nobody knew whether to object.

Prague itself was beautiful, of course. There were bridges and facades and a civic confidence I found thrilling. But memory is unjust. What remains most vividly is the coach at dusk somewhere in Germany, yellow light over the motorway services, and the bizarre dignity of an accordion being played to an unwilling but captive teenage public.

Mr Doyle, the history teacher, eventually asked Carys whether perhaps the instrument could have an early night. She agreed with such politeness that he looked briefly ashamed. That, too, I remember. There are times when enthusiasm survives mainly because nobody has the heart to suppress it completely.
