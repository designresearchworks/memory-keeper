# Story: The Houseboat Meeting

## Metadata
Told: 2026-03-24T13:44:00.000Z
File: stories/the-houseboat-meeting.md
Period: February 2026
People: Mina Vale, Eli Barrett, project partners (unnamed)
Places: Hackney canal
Themes: work meetings, London oddities, professional life, romance beginning, spaces
Connections: none
Summary: A project meeting held on a moored houseboat was objectively impractical but atmospherically effective, and for Mina the event acquired additional significance because Eli was there and beginning to matter.

## Story

I attended a project meeting on a moored houseboat in Hackney and would normally be obliged to say, on principle, that this is not an appropriate environment for serious planning. The chairs were unstable, the coffee was optimistic, and every few minutes a passing wake reminded us that tables can have opinions. Nevertheless the morning was, annoyingly, excellent.

Part of this was spatial. Unusual settings can dislodge stale meeting behaviour if everyone involved has the grace not to perform novelty too hard. People spoke more plainly. The boat made hierarchy faintly ridiculous.

Part of it was simpler. Eli was there.

By that point I already knew I was alert in his presence in a way that exceeded ordinary professional regard. This is awkward territory in work-adjacent contexts because it requires you to continue having sensible thoughts while another track of attention hums underneath. The boat did not help. Water has always been flattering to beginnings.

At one point the conversation drifted into a discussion of public thresholds and who feels invited into cultural spaces. Eli made a point so crisp and humane that I briefly forgot to pretend neutrality. Luckily everyone else was busy balancing notebooks on a tilting table.

The meeting produced actual useful outcomes, which feels important to note for the record. But in memory it is mostly a story about a boat, some bad biscuits, and the early stage of liking someone when your own interpretive machinery becomes embarrassingly well resourced.
