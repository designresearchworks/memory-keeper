# Story: The Day the Pier Speaker Crackled

## Metadata
Told: 2026-03-24T10:00:00.000Z
File: stories/the-day-the-pier-speaker-crackled.md
Period: Summer 1992
People: Mina Vale, Ruth Vale, Theo Vale
Places: Saltmere Pier, North Yorkshire coast
Themes: childhood, seaside, fear, family rituals, public announcements
Connections: The Orange Lifeboat Tin
Summary: As a small child on Saltmere Pier, Mina was terrified by a crackling loudspeaker announcement about a lost boy, convinced for several long minutes that the pier itself had developed a voice. The memory combines comic childhood logic, sea air, and the particular embarrassment of being soothed by a mother who was trying not to laugh.

## Story

One of my earliest dependable memories is of being on Saltmere Pier with my mother and my brother Theo when the public-address speaker above the arcade crackled into life. I cannot have been more than five. Up until that point the pier had seemed to me to be a structure like any other, wooden, windy, faintly sticky from ice cream and salt. Then suddenly it spoke.

The announcement was about a lost boy in a red jumper. That part I understood. What I did not understand was how the voice had got into the roof. I remember looking up with a kind of moral panic, convinced that the pier had either swallowed a person or contained one as part of its internal machinery. My mother tried to explain speakers. Theo, who was old enough to find this funny, made it worse by saying perhaps there was a tiny man living in the rafters whose entire job was to shout about missing children and closing times.

I started to cry, not because I thought the lost boy was in danger exactly, though he probably was, but because the whole arrangement seemed improper. Buildings should not speak. Buildings should creak, perhaps. They should let rain in. They should smell of damp rope and chips. But they should not address the public.

The lost boy was eventually reunited with whoever he had been separated from. I have no recollection of that reunion. What I remember is my mother kneeling to my height, trying to explain amplification while laughing just enough for me to notice. Even then I recognised the injustice of being frightened by something that was apparently also funny. That combination has turned out to be durable. A great many things in life are ridiculous and destabilising at the same time.
