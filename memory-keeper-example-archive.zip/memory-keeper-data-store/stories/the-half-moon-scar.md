# Story: The Half-Moon Scar

## Metadata
Told: 2026-03-25T15:24:00.000Z
File: stories/the-half-moon-scar.md
Period: 2021
People: Mina Vale, surgeon (unnamed), Ida Seddon
Places: Leeds hospital
Themes: cancer, illness, body, fear, survival
Connections: The Shared Umbrella After the Breakup
Summary: Mina’s cancer arrived first as administrative oddness and then as a scar: what remains most vividly is not a heroic narrative but the eerie competence with which the medical system and the body together remapped her life.

## Story

Cancer did not enter my life with revelation. It entered with appointments, blood tests, a consultant using calm nouns, and the growing sense that my body had been holding a private meeting to which I had not been invited. By the time I was told clearly what was wrong, the fear had already become procedural.

I was lucky, as these things go. The treatment path was relatively straightforward, the surgery successful, the prognosis good. I am aware that this sentence contains an entire universe of luck disguised as moderation. Even so, I found illness less noble than people like to imply. Mostly it was tiring, administratively invasive, and bodily strange.

The thing that stays with me is the scar, a pale half-moon near the collarbone that turns up in mirrors and changing rooms as a small persistent grammar of interruption. Bodies keep records too. Not elegantly, not voluntarily, but faithfully enough.

Ida asked me once if it hurt to look at it. I said not exactly. That was the truth. What it does is not pain but scale adjustment. It reminds me that I am a finite animal held together by processes I do not command. There is terror in that. There is also, occasionally, relief.
