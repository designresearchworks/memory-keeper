# Story: The Ice Cream Van at the Protest

## Metadata
Told: 2026-03-24T11:56:00.000Z
File: stories/the-ice-cream-van-at-the-protest.md
Period: 2017
People: Mina Vale, Sana Qureshi, protesters (unnamed)
Places: Leeds Civic Square
Themes: politics, public gatherings, surreal details, friendship, civic life
Connections: The Public Benches Project
Summary: At a serious public protest, an ice cream van positioned itself at the edge of the square with baffling entrepreneurial neutrality. Mina remembers the event through that collision of urgency and everyday commerce.

## Story

One of the strangest things about public protest is how quickly extraordinary collective feeling has to coexist with ordinary commerce. I remember standing in Leeds Civic Square at a serious demonstration about council cuts while, ten yards away, an ice cream van conducted business with complete ideological neutrality.

The juxtaposition was almost offensively neat. Placards, speeches, anger, drumming, chants about social care and libraries, and beside all that a man selling ninety-nines to children who had, one assumes, not come to debate municipal finance. Sana was with me and kept pointing out the surreal details with the analytical delight she reserves for moments when systems fail to coordinate their tone.

I do not mean this cynically. In fact the opposite. The ice cream van seemed to me a reminder that public life is never purified into one register. Seriousness does not get the square to itself. Politics happens among snacks, buses, dogs, weather, and people asking whether anyone knows where the toilets are.

At one point a speaker made a genuinely moving argument about what gets erased when public services are cut. Simultaneously, from just beyond the crowd, the van emitted Greensleeves. The melody floated over everything with unbearable persistence.

I have thought about that often since. Democracy is not staged in acoustically controlled conditions. It happens inside the same civic mess as everything else. Perhaps that is part of its dignity. Or perhaps I am over-intellectualising an unfortunate choice of parking spot.
