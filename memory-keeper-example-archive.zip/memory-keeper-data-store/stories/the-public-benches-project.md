# Story: The Public Benches Project

## Metadata
Told: 2026-03-24T11:48:00.000Z
File: stories/the-public-benches-project.md
Period: 2016
People: Mina Vale, Julian March, residents of Calderford (unnamed)
Places: Calderford
Themes: design research, public space, listening, work, civic life
Connections: The Exhibition That Smelled of Apples
Summary: A project about public benches taught Mina that seemingly minor pieces of street furniture carry huge amounts of social meaning. The work became one of the foundations of her later career in civic design.

## Story

The first project that made me think I might have an actual professional direction involved public benches in a former mill town called Calderford. On paper this sounds almost offensively modest. In practice it turned out to be a near-perfect object of study.

A bench is never just a bench. It is invitation, warning, pause, visibility, nuisance, rest, age, surveillance, companionship, loneliness, waiting, and municipal optimism in timber or metal form. Once you start talking to people about benches, they start telling you about everything else: buses, knees, teenagers, grief, weather, dog routes, where they do and do not feel welcome.

I spent weeks walking the town, photographing seating, talking to residents, and discovering that the exact placement of a bench could determine whether it was used tenderly, ignored completely, or treated as low-grade urban theatre. One older man told me a bench outside the post office had saved his life after a bypass because without it he would never have risked walking into town again. That sentence rearranged something for me.

Design, at least the kind I wanted to practice, was not about imposing taste on public life. It was about understanding the thresholds at which infrastructure becomes permission. Benches are where bodies negotiate with systems. Once I saw that, I could not really go back to thinking of public objects as neutral.
