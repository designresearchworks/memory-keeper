# Story: The Room White, Then Black, Then White Again

## Metadata
Told: 2026-03-25T15:32:00.000Z
File: stories/the-room-white-then-black-then-white-again.md
Period: 2023–2024
People: Mina Vale
Places: Mina’s front room, Leeds
Themes: painting, domestic life, aesthetics, control, recovery
Connections: none
Summary: Painting the same room white, then black, then white again became for Mina a private study in mood, control, and the solemn, nearly liturgical beauty of changing a domestic atmosphere with pigment alone.

## Story

I painted the front room white, then black, then white again over the course of two years, which is either a design process or evidence of an unsettled interior life depending on how generous you feel. I am inclined to think it was both.

The first white was about clearing things after illness and breakup and the general sense that too many textures in my life were already speaking at once. The black came later and felt, for several weeks, exactly right: dramatic, enclosing, a room that could hold thought without reflecting it back so loudly. Then, in winter, it began to feel like living inside an emphatic opinion.

Painting a room is one of the strangest domestic acts because the labour is physical and immediate while the effect is atmospheric and moral. You are not just changing colour. You are altering the terms on which light meets your furniture, your books, your own face in the evening.

When I painted it white again, I felt something I can only describe as solemn relief. Not because white is purer or better. But because the room had completed, in paint, an argument I had needed to have somewhere material. Sometimes the body thinks through walls before it knows how to think through language.
