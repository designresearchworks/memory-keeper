# Story: Nettle on the Vet Table

## Metadata
Told: 2026-03-25T15:12:00.000Z
File: stories/nettle-on-the-vet-table.md
Period: 2019
People: Mina Vale, Nettle the dog, Noor Hamdi
Places: Leeds veterinary clinic
Themes: dog, grief, pets, love, mortality
Connections: The Ceramic Fox on the Mantelpiece
Summary: When Mina’s dog Nettle died, the heartbreak came not only from losing him but from watching a body that had structured years of domestic routine suddenly become still on a stainless-steel table.

## Story

Our dog Nettle died on a wet Tuesday in a veterinary clinic that had tried, with mixed success, to make grief look less fluorescent. He had been going downhill for weeks, and so nothing about the decision was surprising. That did not make the room easier to enter.

Nettle was a border terrier of enormous self-belief and selective obedience. He had organised years of my life around walks, feeding, muddy returns, and the small daily absurdities by which dogs turn human schedules into something more bodily. I had not realised how much of my sense of home was paced by his movement until I saw him lying still on the vet table and felt the whole domestic machinery stop with him.

Noor was with me. We were not yet broken up then, though perhaps some of the fraying had already begun. I remember both of us putting our hands on Nettle at the same time, as if there were still some chance that touch counted administratively. It did not.

Afterwards the house was unbearable in exactly the practical ways grief often is. No claws on the floorboards. No lead by the door that actually needed to be there. No body waiting for the sound of a cupboard. People like to say pets are family, and they are. But they are also timekeepers, route planners, sensory anchors. When they go, the emptiness is infrastructural.
