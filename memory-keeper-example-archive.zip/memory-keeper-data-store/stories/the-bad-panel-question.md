# Story: The Bad Panel Question

## Metadata
Told: 2026-03-24T12:44:00.000Z
File: stories/the-bad-panel-question.md
Period: 2022
People: Mina Vale, conference attendee (unnamed)
Places: Helsinki conference venue
Themes: professional life, public speaking, conference culture, self-control, critique
Connections: none
Summary: After giving a panel talk, Mina received an aggressively overlong audience question disguised as insight. The story is about public composure and the private labour required not to meet vanity with contempt.

## Story

Anyone who speaks on panels for long enough develops a taxonomy of questions. Genuine enquiries. Supportive elaborations. Mildly disguised disagreements. Full speeches pretending to be questions. In Helsinki I encountered an especially ornate example of the last category.

A man in the third row stood up, thanked everyone at immense length, referenced several unrelated theorists, and then began what was clearly an attempt to demonstrate his own interpretive sophistication using my talk as temporary furniture. Minutes passed. The moderator looked trapped between politeness and mortality.

There is a professional skill in not allowing your face to reveal that you have correctly diagnosed a bad-faith performance. I concentrated on looking interested in the broad constitutional principle of dialogue. Internally I was furnishing a small but definite bonfire.

Eventually the man came to a stop in a place that was not grammatically a question but could perhaps be answered as though it were. So I did. Briefly. Calmly. Afterwards a colleague told me I had been generous. What they meant was that I had not publicly punished him.

I am not claiming sainthood here. Mostly I was aware that conferences are small villages with expensive badges. But the episode did remind me that professionalism often consists of declining invitations to become the obvious version of yourself. The obvious version, in that moment, was sharp. The useful version was not.
