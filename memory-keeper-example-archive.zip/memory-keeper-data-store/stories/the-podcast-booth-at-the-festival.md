# Story: The Podcast Booth at the Festival

## Metadata
Told: 2026-03-24T13:28:00.000Z
File: stories/the-podcast-booth-at-the-festival.md
Period: 2025
People: Mina Vale, Eli Barrett
Places: Sheffield festival
Themes: public speaking, media, nerves, storytelling, professional life
Connections: The Bad Panel Question
Summary: Invited into a makeshift podcast booth at a design festival, Mina discovered that being recorded in a tiny foam-lined box with a stranger can feel more exposing than speaking to a roomful of people.

## Story

At a design festival in Sheffield I was invited, with almost no warning, to record a short podcast conversation in a booth made of foam panels and optimism. Public speaking to a room I can do. Sitting twelve inches from a microphone while another human says so tell me how you think about memory? is a different order of vulnerability.

The host, Eli Barrett, was perfectly pleasant, which in some ways made it harder. Abrasiveness you can defend against. Warm curiosity requires actual thought. The booth itself was tiny and over-insulated, producing the sensation of being professionally interrogated inside a mattress.

What unsettled me was the intimacy of recorded speech. In a room, language dissipates. In a podcast booth, every hesitation seems collectible. You can hear your own formulation taking shape and worry, in real time, whether it deserves preservation.

And yet the conversation ended up being good. Or at least real. The constraints helped. There was no space for performative breadth. Only two voices, a few questions, and the need to answer in sentences that sounded like a person rather than a panel abstract.

Afterwards Eli thanked me for being candid. I accepted this with outward normality and inward surprise. Often the thing people call candid is simply the result of not having enough time to hide behind your preferred register.
