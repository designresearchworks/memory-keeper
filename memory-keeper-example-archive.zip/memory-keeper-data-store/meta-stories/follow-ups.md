# Follow-up Questions

## After Story: The Day the Pier Speaker Crackled
Generated: 2026-03-26

- What feels most alive to you now about The Day the Pier Speaker Crackled?
- Does this story want to sit closer to The Orange Lifeboat Tin, or is the current connection mostly tonal?

## After Story: The Orange Lifeboat Tin
Generated: 2026-03-26

- What feels most alive to you now about The Orange Lifeboat Tin?
- Does this story want to sit closer to The Day the Pier Speaker Crackled, or is the current connection mostly tonal?

## After Story: The Cardboard Castle in the Rain
Generated: 2026-03-26

- What feels most alive to you now about The Cardboard Castle in the Rain?
- Does this story want to sit closer to The Orange Lifeboat Tin, or is the current connection mostly tonal?

## After Story: The Library Key on Blue String
Generated: 2026-03-26

- What feels most alive to you now about The Library Key on Blue String?
- What detail from this memory feels larger now than it did when it happened?

## After Story: The Red Coat on the Footbridge
Generated: 2026-03-26

- What feels most alive to you now about The Red Coat on the Footbridge?
- Does this story want to sit closer to The Library Key on Blue String, or is the current connection mostly tonal?

## After Story: The Accordion on the Coach to Prague
Generated: 2026-03-26

- What feels most alive to you now about The Accordion on the Coach to Prague?
- Does this story want to sit closer to The Red Coat on the Footbridge, or is the current connection mostly tonal?

## After Story: The Basement Darkroom
Generated: 2026-03-26

- What version of yourself do you meet again when you return to The Basement Darkroom?
- What were you trying to become at that point, and what do you see more clearly now?

## After Story: The Cafe with the Orange Formica
Generated: 2026-03-26

- What version of yourself do you meet again when you return to The Cafe with the Orange Formica?
- What were you trying to become at that point, and what do you see more clearly now?

## After Story: The Married Ceramicist
Generated: 2026-03-26

- What version of yourself do you meet again when you return to The Married Ceramicist?
- What were you trying to become at that point, and what do you see more clearly now?

## After Story: The Girl with the Silver Shaved Head
Generated: 2026-03-26

- What version of yourself do you meet again when you return to The Girl with the Silver Shaved Head?
- What were you trying to become at that point, and what do you see more clearly now?

## After Story: The Apple and the Spoon
Generated: 2026-03-26

- What part of The Apple and the Spoon still feels bodily or emotionally present now?
- What changed in your understanding of yourself after this, even if the change was slow or hard to name?

## After Story: The Warehouse with the Painted Floor
Generated: 2026-03-26

- What version of yourself do you meet again when you return to The Warehouse with the Painted Floor?
- What were you trying to become at that point, and what do you see more clearly now?

## After Story: The Call Centre Voice
Generated: 2026-03-26

- What feels most alive to you now about The Call Centre Voice?
- Does this story want to sit closer to The Warehouse with the Painted Floor, or is the current connection mostly tonal?

## After Story: The Exhibition That Smelled of Apples
Generated: 2026-03-26

- What feels most alive to you now about The Exhibition That Smelled of Apples?
- Does this story want to sit closer to The Call Centre Voice, or is the current connection mostly tonal?

## After Story: The Public Benches Project
Generated: 2026-03-26

- What feels most alive to you now about The Public Benches Project?
- Does this story want to sit closer to The Exhibition That Smelled of Apples, or is the current connection mostly tonal?

## After Story: The Ice Cream Van at the Protest
Generated: 2026-03-26

- What feels most alive to you now about The Ice Cream Van at the Protest?
- Does this story want to sit closer to The Public Benches Project, or is the current connection mostly tonal?

## After Story: The Lantern Parade in Rain
Generated: 2026-03-26

- What feels most alive to you now about The Lantern Parade in Rain?
- Does this story want to sit closer to The Public Benches Project, or is the current connection mostly tonal?

## After Story: The Bad Panel Question
Generated: 2026-03-26

- What feels most alive to you now about The Bad Panel Question?
- What detail from this memory feels larger now than it did when it happened?

## After Story: The Museum of Failed Signs
Generated: 2026-03-26

- What feels most alive to you now about The Museum of Failed Signs?
- Does this story want to sit closer to The Public Benches Project, or is the current connection mostly tonal?

## After Story: The Podcast Booth at the Festival
Generated: 2026-03-26

- What feels most alive to you now about The Podcast Booth at the Festival?
- Does this story want to sit closer to The Bad Panel Question, or is the current connection mostly tonal?

## After Story: The Ceramic Fox on the Mantelpiece
Generated: 2026-03-26

- What did The Ceramic Fox on the Mantelpiece clarify for you about love, family, or responsibility?
- Is there another family story that would make this one feel less like a single threshold and more like part of a longer arc?

## After Story: The Shared Umbrella After the Breakup
Generated: 2026-03-26

- What did The Shared Umbrella After the Breakup clarify for you about love, family, or responsibility?
- Is there another family story that would make this one feel less like a single threshold and more like part of a longer arc?

## After Story: Nettle on the Vet Table
Generated: 2026-03-26

- What part of Nettle on the Vet Table still feels bodily or emotionally present now?
- What changed in your understanding of yourself after this, even if the change was slow or hard to name?

## After Story: The Adoption Order at Wakefield
Generated: 2026-03-26

- What did The Adoption Order at Wakefield clarify for you about love, family, or responsibility?
- Is there another family story that would make this one feel less like a single threshold and more like part of a longer arc?

## After Story: The Ditch on the A65
Generated: 2026-03-26

- What feels most alive to you now about The Ditch on the A65?
- Does this story want to sit closer to The Shared Umbrella After the Breakup, or is the current connection mostly tonal?

## After Story: The Half-Moon Scar
Generated: 2026-03-26

- What part of The Half-Moon Scar still feels bodily or emotionally present now?
- What changed in your understanding of yourself after this, even if the change was slow or hard to name?

## After Story: The Argument in Carriage B
Generated: 2026-03-26

- What feels most alive to you now about The Argument in Carriage B?
- Does this story want to sit closer to The Bad Panel Question, or is the current connection mostly tonal?

## After Story: The Room White, Then Black, Then White Again
Generated: 2026-03-26

- What feels most alive to you now about The Room White, Then Black, Then White Again?
- What detail from this memory feels larger now than it did when it happened?

## After Story: The Houseboat Meeting
Generated: 2026-03-26

- What version of yourself do you meet again when you return to The Houseboat Meeting?
- What were you trying to become at that point, and what do you see more clearly now?

## After Story: The Train Driver at Haworth
Generated: 2026-03-26

- What version of yourself do you meet again when you return to The Train Driver at Haworth?
- What were you trying to become at that point, and what do you see more clearly now?

## After Story: The Letterpress Card from Ruth
Generated: 2026-03-26

- What feels most alive to you now about The Letterpress Card from Ruth?
- What detail from this memory feels larger now than it did when it happened?

## After Story: The Memio Experiment
Generated: 2026-03-26

- What feels most alive to you now about The Memio Experiment?
- What detail from this memory feels larger now than it did when it happened?

## After Story: The Compost Heap in January
Generated: 2026-03-26

- What changed in your attention after The Compost Heap in January, if anything?
- What did this encounter let you notice about Mina’s garden, Leeds that you had previously been treating as background?

## After Story: The Fox Path Behind the Allotments
Generated: 2026-03-26

- What changed in your attention after The Fox Path Behind the Allotments, if anything?
- What did this encounter let you notice about Leeds allotments that you had previously been treating as background?

## After Story: The Heron at the Retention Pond
Generated: 2026-03-26

- What changed in your attention after The Heron at the Retention Pond, if anything?
- What did this encounter let you notice about Retail-park retention pond, Leeds that you had previously been treating as background?

## After Story: The Worms After the Downpour
Generated: 2026-03-26

- What changed in your attention after The Worms After the Downpour, if anything?
- What did this encounter let you notice about Leeds pavement after rain that you had previously been treating as background?

## After Story: The Lichen on the Bench Slat
Generated: 2026-03-26

- What changed in your attention after The Lichen on the Bench Slat, if anything?
- What did this encounter let you notice about Calderford riverside bench that you had previously been treating as background?

## After Story: The Rain Garden by the Council Offices
Generated: 2026-03-26

- What changed in your attention after The Rain Garden by the Council Offices, if anything?
- What did this encounter let you notice about Calderford council offices that you had previously been treating as background?
