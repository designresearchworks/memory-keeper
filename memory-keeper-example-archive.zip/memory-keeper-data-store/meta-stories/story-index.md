# Memory Keeper — Story Index

# Storyteller: Mina

---

## Stories

### The Day the Pier Speaker Crackled
File: stories/the-day-the-pier-speaker-crackled.md
Told: 2026-03-24
Period: Summer 1992
People: Mina Vale, Ruth Vale, Theo Vale
Places: Saltmere Pier, North Yorkshire coast
Themes: childhood, seaside, fear, family rituals, public announcements
Connections: The Orange Lifeboat Tin
Summary: As a small child on Saltmere Pier, Mina was terrified by a crackling loudspeaker announcement about a lost boy, convinced for several long minutes that the pier itself had developed a voice. The memory combines comic childhood logic, sea air, and the particular embarrassment of being soothed by a mother who was trying not to laugh.

### The Orange Lifeboat Tin
File: stories/the-orange-lifeboat-tin.md
Told: 2026-03-24
Period: Early 1990s
People: Mina Vale, Adrian Vale, Theo Vale
Places: Saltmere harbour, Vale family kitchen
Themes: childhood collections, saving objects, seaside towns, father-daughter rituals
Connections: The Day the Pier Speaker Crackled
Summary: Mina and her father developed a habit of dropping spare coins into an orange RNLI collection tin shaped like a lifeboat. The object became less about charity in the abstract than about sound, ritual, and the comforting idea that small repeated acts could keep disaster offshore.

### The Cardboard Castle in the Rain
File: stories/the-cardboard-castle-in-the-rain.md
Told: 2026-03-24
Period: Autumn 1994
People: Mina Vale, Leah Porter, Ruth Vale
Places: Vale family garden, Saltmere
Themes: childhood projects, weather, friendship, failure, imagination
Connections: The Orange Lifeboat Tin
Summary: A painstaking cardboard castle built in the garden with her friend Leah dissolved in a sudden rainstorm before either girl was willing to admit the project had been badly conceived from the start. Mina remembers less the disappointment than the stubborn loyalty they briefly showed to a structure that was obviously turning back into pulp.

### The Library Key on Blue String
File: stories/the-library-key-on-blue-string.md
Told: 2026-03-24
Period: 1999
People: Mina Vale, Mrs Frobisher
Places: Saltmere Comprehensive School library
Themes: books, school sanctuaries, minor privileges, adolescence, trust
Connections: none
Summary: Being allowed to open the school library at lunchtime with a key on a blue cord felt to Mina like a promotion into a hidden adult order. The privilege was tiny in practical terms but large in imaginative ones.

### The Red Coat on the Footbridge
File: stories/the-red-coat-on-the-footbridge.md
Told: 2026-03-24
Period: Around 2001
People: Mina Vale, Euan Mercer
Places: Railway footbridge, Saltmere
Themes: first love, teenage longing, railway towns, missed timing, weather
Connections: The Library Key on Blue String
Summary: A brief teenage romance acquired disproportionate emotional significance because it mostly consisted of waiting for one another in the wrong places at almost the right times. The image Mina keeps is of a red coat on a railway bridge in sleet.

### The Accordion on the Coach to Prague
File: stories/the-accordion-on-the-coach-to-prague.md
Told: 2026-03-24
Period: Spring 2004
People: Mina Vale, Carys Bennett, Mr Doyle
Places: Prague, school trip coach
Themes: school trips, Europe, awkward travel, music, adolescence
Connections: The Red Coat on the Footbridge
Summary: A school trip to Prague was improved and slightly deranged by a fellow pupil who had inexplicably brought an accordion and kept playing fragments of songs at border crossings. Mina remembers the trip less for the city than for the surreal social texture of getting there.

### The Basement Darkroom
File: stories/the-basement-darkroom.md
Told: 2026-03-24
Period: 2005
People: Mina Vale, Luca Fenner
Places: Glasgow School of Art annexe
Themes: art school, photography, craft, young adulthood, romance
Connections: The Accordion on the Coach to Prague
Summary: At art school, Mina spent evenings in a basement darkroom learning how much patience analogue photography demanded and how attractive competence looked under a red safelight. The story captures the tactile seriousness of making things slowly.

### The Cafe with the Orange Formica
File: stories/the-cafe-with-the-orange-formica.md
Told: 2026-03-25
Period: 2006, art-school years
People: Mina Vale, Mags Ritchie, customers (unnamed)
Places: The Saucer and String cafe, Glasgow
Themes: art school, cafe work, young adulthood, service work, observation
Connections: The Call Centre Voice, The Warehouse with the Painted Floor
Summary: While at art school, Mina worked in a cafe with orange Formica tables and learned more than she expected about class performance, repetition, and how much of adulthood is built from carrying plates while overhearing the truth.

### The Married Ceramicist
File: stories/the-married-ceramicist.md
Told: 2026-03-25
Period: 2007
People: Mina Vale, Rafe Bell
Places: Glasgow School of Art annexe, Rafe’s studio flat
Themes: affair, art school, desire, bad decisions, power
Connections: The Basement Darkroom, The Girl with the Silver Shaved Head
Summary: Mina’s affair with a married ceramicist a few years older than her was not, even at the time, something she mistook for wisdom; what she remembers now is the atmosphere of adult permission it seemed to offer and the hollowness underneath.

### The Girl with the Silver Shaved Head
File: stories/the-girl-with-the-silver-shaved-head.md
Told: 2026-03-25
Period: 2006
People: Mina Vale, Mara Quinn
Places: Glasgow art-school party, Mara’s flat
Themes: queer desire, art school, women, identity, awkward tenderness
Connections: The Married Ceramicist, The Red Coat on the Footbridge
Summary: Trying to sleep with women during art school was, for Mina, less a cleanly declared identity than a series of earnest, awkward, often revelatory encounters, none more memorable than a night with a girl called Mara whose shaved silver head made her seem braver than anyone Mina knew.

### The Apple and the Spoon
File: stories/the-apple-and-the-spoon.md
Told: 2026-03-25
Period: 2005, first year at art school
People: Mina Vale
Places: Glasgow student flat
Themes: eating disorder, art school, body image, control, young adulthood
Connections: The Basement Darkroom, The Girl with the Silver Shaved Head
Summary: Mina’s eating disorder episode at art school was less theatrical than people imagine such things to be; what she remembers is the smallness of the rituals and the way self-starvation masqueraded as discipline and aesthetic seriousness.

### The Warehouse with the Painted Floor
File: stories/the-warehouse-with-the-painted-floor.md
Told: 2026-03-24
Period: 2006
People: Mina Vale, Tobias Reed, Sana Qureshi
Places: Glasgow
Themes: student housing, creative life, mess, friendship, young adulthood
Connections: The Basement Darkroom
Summary: Mina lived for a year in a converted warehouse flat whose painted concrete floor was always cold and always somehow social. The story is about communal living, improvised adulthood, and the affection that can attach itself to impractical spaces.

### The Call Centre Voice
File: stories/the-call-centre-voice.md
Told: 2026-03-24
Period: 2008
People: Mina Vale, Helen Draper
Places: Leeds
Themes: first jobs, performance of self, workplace culture, voice, survival
Connections: The Warehouse with the Painted Floor
Summary: Working briefly in a call centre taught Mina that the voice one uses for paid reassurance is both a practical tool and a mild estrangement from oneself. The job was not terrible, but it was clarifying in the way temporary jobs often are.

### The Exhibition That Smelled of Apples
File: stories/the-exhibition-that-smelled-of-apples.md
Told: 2026-03-24
Period: 2009
People: Mina Vale, Julian March
Places: Leeds City Museum
Themes: museum work, design, sensory experience, professional growth, experiments
Connections: The Call Centre Voice
Summary: On an early museum project, a curator insisted that an exhibition about orchards should literally smell of apples. The resulting compromise was technically imperfect but formative for Mina, who began to understand exhibition design as choreography rather than arrangement.

### The Public Benches Project
File: stories/the-public-benches-project.md
Told: 2026-03-24
Period: 2016
People: Mina Vale, Julian March, residents of Calderford (unnamed)
Places: Calderford
Themes: design research, public space, listening, work, civic life
Connections: The Exhibition That Smelled of Apples
Summary: A project about public benches taught Mina that seemingly minor pieces of street furniture carry huge amounts of social meaning. The work became one of the foundations of her later career in civic design.

### The Ice Cream Van at the Protest
File: stories/the-ice-cream-van-at-the-protest.md
Told: 2026-03-24
Period: 2017
People: Mina Vale, Sana Qureshi, protesters (unnamed)
Places: Leeds Civic Square
Themes: politics, public gatherings, surreal details, friendship, civic life
Connections: The Public Benches Project
Summary: At a serious public protest, an ice cream van positioned itself at the edge of the square with baffling entrepreneurial neutrality. Mina remembers the event through that collision of urgency and everyday commerce.

### The Lantern Parade in Rain
File: stories/the-lantern-parade-in-rain.md
Told: 2026-03-24
Period: 2018
People: Mina Vale, Asha Karim, children of Calderford (unnamed)
Places: Calderford
Themes: community events, weather, design work, public joy, fragility
Connections: The Public Benches Project
Summary: A community lantern parade that had been painstakingly designed around light and atmosphere had to proceed in stubborn rain. The event still worked, but differently, teaching Mina something about designing for adaptation rather than ideal conditions.

### The Bad Panel Question
File: stories/the-bad-panel-question.md
Told: 2026-03-24
Period: 2022
People: Mina Vale, conference attendee (unnamed)
Places: Helsinki conference venue
Themes: professional life, public speaking, conference culture, self-control, critique
Connections: none
Summary: After giving a panel talk, Mina received an aggressively overlong audience question disguised as insight. The story is about public composure and the private labour required not to meet vanity with contempt.

### The Museum of Failed Signs
File: stories/the-museum-of-failed-signs.md
Told: 2026-03-24
Period: 2022
People: Mina Vale, Asha Karim
Places: Manchester
Themes: design humour, wayfinding, work ideas, friendship, cities
Connections: The Public Benches Project
Summary: Mina and Asha developed a half-serious idea for an exhibition made entirely of confusing or contradictory public signs. The concept never became a project, but the conversation captured how they think together.

### The Podcast Booth at the Festival
File: stories/the-podcast-booth-at-the-festival.md
Told: 2026-03-24
Period: 2025
People: Mina Vale, Eli Barrett
Places: Sheffield festival
Themes: public speaking, media, nerves, storytelling, professional life
Connections: The Bad Panel Question
Summary: Invited into a makeshift podcast booth at a design festival, Mina discovered that being recorded in a tiny foam-lined box with a stranger can feel more exposing than speaking to a roomful of people.

### The Ceramic Fox on the Mantelpiece
File: stories/the-ceramic-fox-on-the-mantelpiece.md
Told: 2026-03-24
Period: 2017
People: Mina Vale, Noor Hamdi
Places: Calderford
Themes: home life, objects, breakups beginning, domestic symbolism, silence
Connections: none
Summary: A ceramic fox bought impulsively and displayed for years became, late in Mina and Noor’s relationship, a strange stand-in for all the things in a home that survive changes in feeling longer than one expects.

### The Shared Umbrella After the Breakup
File: stories/the-shared-umbrella-after-the-breakup.md
Told: 2026-03-24
Period: 2019
People: Mina Vale, Noor Hamdi
Places: Leeds station
Themes: breakup, kindness, rain, ambiguity, adult endings
Connections: The Ceramic Fox on the Mantelpiece
Summary: Shortly after their breakup, Mina and Noor found themselves sharing an umbrella from the station because neither wanted to perform hostility. The moment was awkward, generous, and impossible to classify neatly.

### Nettle on the Vet Table
File: stories/nettle-on-the-vet-table.md
Told: 2026-03-25
Period: 2019
People: Mina Vale, Nettle the dog, Noor Hamdi
Places: Leeds veterinary clinic
Themes: dog, grief, pets, love, mortality
Connections: The Ceramic Fox on the Mantelpiece
Summary: When Mina’s dog Nettle died, the heartbreak came not only from losing him but from watching a body that had structured years of domestic routine suddenly become still on a stainless-steel table.

### The Adoption Order at Wakefield
File: stories/the-adoption-order-at-wakefield.md
Told: 2026-03-25
Period: 2018
People: Mina Vale, Frances Seddon, Ida Seddon
Places: Wakefield family court
Themes: adoption, family, co-parenting, responsibility, love
Connections: The Shared Umbrella After the Breakup, The Letterpress Card from Ruth
Summary: Formally adopting Frances’s daughter Ida altered Mina’s understanding of family more deeply than romance had; what she remembers is the bureaucratic plainness of the court against the scale of what was actually happening.

### The Ditch on the A65
File: stories/the-ditch-on-the-a65.md
Told: 2026-03-25
Period: Winter 2017
People: Mina Vale, Frances Seddon
Places: A65 near Skipton
Themes: car crash, weather, fear, luck, driving
Connections: The Shared Umbrella After the Breakup
Summary: Mina crashed her car on the A65 in sleet, not at great speed but at exactly the wrong angle, and remembers the event as a humiliating lesson in how quickly control can become narrative after the body has already lost it.

### The Half-Moon Scar
File: stories/the-half-moon-scar.md
Told: 2026-03-25
Period: 2021
People: Mina Vale, surgeon (unnamed), Ida Seddon
Places: Leeds hospital
Themes: cancer, illness, body, fear, survival
Connections: The Shared Umbrella After the Breakup
Summary: Mina’s cancer arrived first as administrative oddness and then as a scar: what remains most vividly is not a heroic narrative but the eerie competence with which the medical system and the body together remapped her life.

### The Argument in Carriage B
File: stories/the-argument-in-carriage-b.md
Told: 2026-03-25
Period: 2022
People: Mina Vale, train passenger (unnamed), conductor (unnamed)
Places: London to Leeds train
Themes: anger, trains, public shame, fatigue, temper
Connections: The Bad Panel Question
Summary: After months of illness, work strain, and bad sleep, Mina finally lost her temper on a train in a way she still regrets: not because anger is always wrong, but because public rage leaves such a poor residue of self.

### The Room White, Then Black, Then White Again
File: stories/the-room-white-then-black-then-white-again.md
Told: 2026-03-25
Period: 2023–2024
People: Mina Vale
Places: Mina’s front room, Leeds
Themes: painting, domestic life, aesthetics, control, recovery
Connections: none
Summary: Painting the same room white, then black, then white again became for Mina a private study in mood, control, and the solemn, nearly liturgical beauty of changing a domestic atmosphere with pigment alone.

### The Houseboat Meeting
File: stories/the-houseboat-meeting.md
Told: 2026-03-24
Period: February 2026
People: Mina Vale, Eli Barrett, project partners (unnamed)
Places: Hackney canal
Themes: work meetings, London oddities, professional life, romance beginning, spaces
Connections: none
Summary: A project meeting held on a moored houseboat was objectively impractical but atmospherically effective, and for Mina the event acquired additional significance because Eli was there and beginning to matter.

### The Train Driver at Haworth
File: stories/the-train-driver-at-haworth.md
Told: 2026-03-25
Period: Autumn 2023
People: Mina Vale, Ellen Mowbray
Places: Haworth, Keighley and Worth Valley Railway, Bronte country
Themes: Haworth, Bronte country, train driver, women, romance, landscape
Connections: none
Summary: A trip to Haworth in search of Bronte atmosphere became, unexpectedly, the beginning of a short and sincere love with a woman who drove heritage trains and looked at the moors as if they were colleagues rather than scenery.

### The Letterpress Card from Ruth
File: stories/the-letterpress-card-from-ruth.md
Told: 2026-03-24
Period: 2026
People: Mina Vale, Ruth Vale
Places: Leeds
Themes: mother-daughter relationships, cards, language, family affection, small gifts
Connections: none
Summary: A short card from Mina’s mother, written in sparse but exact language, meant more to her than more elaborate gestures often do. The story is about the family style of affection through understatement.

### The Memio Experiment
File: stories/the-memio-experiment.md
Told: 2026-03-24
Period: March 2026
People: Mina Vale, Eli Barrett
Places: Leeds, Saltmere, online
Themes: memory technology, self-reference, archives, voice notes, new beginnings
Connections: none
Summary: Mina and Eli began experimenting with a memory-keeping archive for Mina’s own stories, partly as a design exercise and partly because Mina already had the instincts of an archivist without a sufficiently good system. The project felt both practical and oddly intimate.

### The Compost Heap in January
File: stories/the-compost-heap-in-january.md
Told: 2026-03-25
Period: January 2022
People: Mina Vale
Places: Mina’s garden, Leeds
Themes: more-than-human, compost, seasonality, gardening, material cycles
Connections: The Memio Experiment
Summary: Turning the compost in winter, Mina became briefly fascinated by the heat rising from decay and by the fact that the most visibly dead part of the garden was also, in process terms, the busiest.

### The Fox Path Behind the Allotments
File: stories/the-fox-path-behind-the-allotments.md
Told: 2026-03-25
Period: Spring 2021
People: Mina Vale, Asha Karim
Places: Leeds allotments
Themes: more-than-human, foxes, allotments, attention, urban ecology
Connections: The Public Benches Project
Summary: While cutting through the allotments at dusk, Mina and Asha gradually realised they were not following a desire path made by humans at all but a fox route, worn into the margins by another city-user with older priorities than theirs.

### The Heron at the Retention Pond
File: stories/the-heron-at-the-retention-pond.md
Told: 2026-03-25
Period: Autumn 2024
People: Mina Vale, Eli Barrett
Places: Retail-park retention pond, Leeds
Themes: more-than-human, herons, retention ponds, suburban ecology, attention
Connections: The Public Benches Project
Summary: A heron standing beside a stormwater retention pond behind a retail park looked, to Mina, less like a symbol of wildness than a patient professional making use of the drainage compromises of late capitalism.

### The Worms After the Downpour
File: stories/the-worms-after-the-downpour.md
Told: 2026-03-25
Period: October 2023
People: Mina Vale
Places: Leeds pavement after rain
Themes: more-than-human, worms, rain, pavements, care
Connections: The Compost Heap in January
Summary: After heavy rain, Mina found herself repeatedly moving stranded worms off the pavement with a leaf, embarrassed by the tenderness of it but unwilling to stop.

### The Lichen on the Bench Slat
File: stories/the-lichen-on-the-bench-slat.md
Told: 2026-03-25
Period: 2025
People: Mina Vale
Places: Calderford riverside bench
Themes: more-than-human, lichen, benches, slow time, public space
Connections: The Public Benches Project
Summary: Noticing a scatter of lichen on the underside of a riverside bench slat, Mina was reminded that even the furniture she helped think about enters longer, stranger timescales than use alone suggests.

### The Rain Garden by the Council Offices
File: stories/the-rain-garden-by-the-council-offices.md
Told: 2026-03-25
Period: 2025
People: Mina Vale, council officer (unnamed)
Places: Calderford council offices
Themes: more-than-human, rain gardens, civic design, water, plants
Connections: The Public Benches Project, The Heron at the Retention Pond
Summary: A small rain garden outside the council offices felt to Mina like one of the more honest forms of civic design, because it openly admitted water, plants, and maintenance into the same sentence.
